function [bestf,tauvals,besttt,adflag,bestbetas,bicrun]=two(jc,ehatw,differe,perc,margin,jcmax,pmax,minobs,ngrid);
%%%%%%%%%%%%%%%%%%%%%%
% Feb 1, 2012
% % % % % % % best version
% takes first and second thresholds as inputs, searches for the third
% % % % % % %        
% input first, second thresholds
% CR residuals
% margin = 1 if indicators based on difference between y and first column of x
%             = 0 if lagged CR
% margins based on differe series from main program difference between y
% and first column of y, gls if gls used
% perc set for threshold search
% jcmax is max value for threshold indicator lag
% pmax is max lag of adf component determined by bic
% minobs is the min # of observations within each threshold region
% jc fixed for threshold indicator lag from first threshold choice
% returns:  best Seo F test, threshold values, threshold indicator lag,
% best t statistics on specification giving highest Seo F test
% adf lag on specification giving highest Seo F test
% beta coefficients specification giving highest Seo F test
% bic value
%
% %
% ehatlw=ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
% dehatw=ehatw(2+pmax+jcmax:rows(ehatw),1)-ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
% %  
% % 
% % 
% %now calculate F test using OLS covariance matrix assuming no
% %  thresholds
% % dehatw is the change in the CR residuals, ehatlw is the lagged CR
% beta=[inv(ehatlw'*ehatlw)]*(ehatlw'*dehatw);
% [a,b]=size(ehatlw) ;
% % create residuals
%  res=dehatw-ehatlw*beta;
%  % create SSR
%  ssra=res'*res;
%  %
%  %disp('No threshold sigmahat')
%  sigmahat=ssra/(a);
%  topsig=sigmahat;
%   % set lag adjustment in Newey West covariance matrix to value in d below
%   
%
% 
      
%###################################################   start threshold
%indicator search
 
 % create data
 diffd1=differe(1+pmax+jcmax-jc:rows(differe)-1-jc,1);
ehatvar=ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
  ehatlw=ehatw(1+pmax+jcmax-jc:rows(ehatw)-1-jc,1);
   dehatw1=ehatw(2+pmax+jcmax:rows(ehatw),1)-ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
           
 
     
   if margin==0
      
 n11=fix(perc*(rows(diffd1)));
n12=fix((1-perc)*(rows(diffd1)));
scrit=sort(diffd1);
ed1=(scrit(n12-minobs,1)-scrit(n11,1))/ngrid;
ed2=(scrit(n12,1)-scrit(n11+minobs,1))/ngrid;
%ed3=(scrit(n12,1)-scrit(n11+2*minobs,1))/ngrid;

    thresholdsa=(scrit(n11,1):ed1:scrit(n12-minobs,1))';
    thresholdse=(scrit(n11+minobs,1):ed2:scrit(n12,1))';
 %   thresholdsb=(scrit(n11+(2*minobs),1):ed3:scrit(n12,1))';
    
   else
  n11=fix(perc*(rows(ehatlw)));
n12=fix((1-perc)*(rows(ehatlw)));
scrit=sort(ehatlw);
 
ed1=(scrit(n12-minobs,1)-scrit(n11,1))/ngrid;
ed2=(scrit(n12,1)-scrit(n11+minobs,1))/ngrid;
%ed3=(scrit(n12,1)-scrit(n11+2*minobs,1))/ngrid;

    thresholdsa=(scrit(n11,1):ed1:scrit(n12-minobs,1))';
    thresholdse=(scrit(n11+minobs,1):ed2:scrit(n12,1))';
    %thresholdsb=(scrit(n11+(2*minobs),1):ed3:scrit(n12,1))';
                  
   end
  
    
    
maxcount=rows(thresholdsa)*rows(thresholdse);
fftestboots99=zeros(maxcount,1);
adflag1=zeros(maxcount,1);
boottss99=zeros(maxcount,pmax+3);
bestbetas99=zeros(maxcount,pmax+3);
thresholds=zeros(maxcount,2);
bicva=zeros(maxcount,1);
sraegre1=zeros(rows(diffd1),1);
sraegre2=zeros(rows(diffd1),1);
sraegre3=zeros(rows(diffd1),1);
%sraegre4=zeros(rows(diffd1),1);

    counterb=0;
    
    
    [thresholdsa thresholdse]=ndgrid(thresholdsa,thresholdse);
   [thresholds]=[thresholdsa(:) thresholdse(:)];
 
for i=1:1:rows(thresholds)
    
seconda=thresholds(i,1);
firstt=thresholds(i,2);
%secondb=thresholds(i,3);
 if margin==0
            
    % for i=1:1:rows(diffd1)
 
           sraegre1=(diffd1<=seconda).*ehatvar;
           sraegre2=((diffd1>seconda)&(diffd1<=firstt)).*ehatvar;
           sraegre3=(diffd1>firstt).*ehatvar;  
            
 
 end
     
  
            if margin==1

           sraegre1=(ehatlw<=seconda).*ehatvar;
           sraegre2=((ehatlw>seconda)&(ehatlw<=firstt)).*ehatvar;
           sraegre3=(ehatlw>firstt).*ehatvar;  
         
            end
             

    % ensure minobs met
    
    j1=sraegre1(sraegre1~=0); rj1=rows(j1);
    j2=sraegre2(sraegre2~=0);rj2=rows(j2);
    j3=sraegre3(sraegre3~=0);rj3=rows(j3);
  
   rj1;
   rj2;
   rj3;
   
   cpeterabce=horzcat(sraegre1,sraegre2,sraegre3);
   
   if rj1>=minobs && rj2>=minobs && rj3>=minobs  

   [~,betaboots5,tsboot5,seosignew,~,topsignew,adflag11,bicval]=ftessadftwo(dehatw1,cpeterabce,pmax);  
g1=cols(tsboot5);
   boottss99(i,:)=horzcat(tsboot5,zeros(1,pmax+3-g1));
   bestbetas99(i,:)=horzcat(betaboots5,zeros(1,pmax+3-g1));
 %here
 
     fftestboots99(i,1)=rows(dehatw1)*((topsignew/seosignew)-1);
     adflag1(i,1)=adflag11;
     bicva(i,1)=bicval;
   else
       fftestboots99(i,1)=0.;
   boottss99(i,1:pmax+3)=zeros(1,pmax+3);
     adflag1(i,1)=0;
     bestbetas99(i,1:pmax+3)=zeros(1,pmax+3);
 
    bicva(i,1)=0;
   end
   %here
    
end

 [~,wil2]=max(fftestboots99); 
   bestf=fftestboots99(wil2,1);
   tauvals=thresholds(wil2,1:2);
   besttt=boottss99(wil2,1:pmax+3);
   bestinfolag=jc;
adflag=adflag1(wil2,1);
bestbetas=bestbetas99(wil2,1:pmax+3);
bicrun=bicva(wil2,1);


  


 
 