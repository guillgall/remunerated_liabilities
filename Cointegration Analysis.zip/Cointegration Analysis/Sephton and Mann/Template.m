clear all;                                                                 
close all;

[data, ColumnHeaders, RawData] = xlsread('Cointegration_Data (Matlab)',1,'A1:AF193');     % take the data

% 
SeriesA=log(data(:,21));
SeriesB=log(data(:,22));

gls=0;
margin=1;
nboot=9999;
blocklen=6;
jcmax=3;
pmax=6;
maxecmlag=6;
ecm=0;
garch=0;
minobs=24;
seosearch=0;
lambda=0;
ngrid=50;
perc=.10;
det=1;
ecm=0;

sm2016(SeriesA,SeriesB,det,gls,perc,margin,nboot,blocklen,jcmax,pmax,maxecmlag,ecm,garch,minobs,seosearch,lambda,ngrid)

