function []=sm2016(x,y,det,gls,perc,margin,nboot,blocklen,jcmax,pmax,maxecmlag,ecm,garch,minobs,seosearch,lambda,ngrid);
%%%%%%%%%%%%%%%%%%%%%%
% july 29 2016 changed ehatw=cr to ehatw=yd-xd*(xd\yd);
%
% Jan 4, 2013
% best version for Tar model uses bic2 if lambda=2, bic if lambda=1 and aic
% if lambda=0
%
% inputs:
% x matrix, y vector, cr MARS cointegrating regression residuals
tic
% det = 1 if trend
% det = 0 if constant
% march 13 2012 added det=-1 for no constant 
%gls =1 if gls detrend
% gls=0 if do not gls detrend
% perc used for threshold search, set as percentage of sample size
% margin = 0 means threshold indicator determined as  function of the lagged y
% series minus the lagged first column of x matrix
% margin = 1 means threshold indicator determined as the lagged CR residual
% nboot the number of bootstrap replications
% blocklen the block length used in bootstrapping
% jcmax the maximum lag of the threshold indicator variable
% pmax the max lag for the ADF version of the tests
% maxecmlag is the max lag in the ECM model
% ECM = 1 if constant in the ECM
%  ECM = 0 if no constant in ECM
%
% NOTE       ECM = 1 makes sense only if GLS = 0 
%
% garch = 1 if you want garch in the ECM residuals
% garch = 0 if you do not want garch in the ECM residuals
% minobs is the min number of obs in each threshold region
%
% seosearch=0  bootstrapping threshold search based on Seo's RANDOM gamma
% approach where threshold range a function of the bootstrap variable
% true only if margin=0 since in the case margin=1 we use the actual lagged
% difference between y and the first column of x
%
% seosearch=1 uses actual range used in first search, what Seo calls fixed
% gamma
% number of thresholds determined by minimizing an objective function
%
% criterion = log(SSR) + (m+1)*k*lambda/T   
% 
% m=[0,3], k=1
%  lambda = 1 use Gonpit criterion based on BIC, lambda term=log(T)
% lambda = 0 use Gonpit criterion based on AIC, lambda term=2
% lambda =2 use BIC2 where lambda=2log(T)

 
    disp('Threshold Choice using Seo')
     if seosearch==0
            disp('Bootstrapping range for Thresholds via Random')
            disp('(using Perc')
        else
        disp('Bootstrapping range for Thresholds via fixed Approach')
        disp('using actual range in initial search')
     end
    
    
    %%%%pause
            
maxip=pmax;
%%%%%%%%%%%%%%%%%%%%%%
% For threshold search lambda=1 means bic
% lambda=0 means aic
%%%%%%%%%%%%%%%%%%%%%%%
%  
%
%%%%%%%%%%%%%%%%%%%%%%%%
% for F test
%%%%%%%%%%%%%%%%%%%%%%%%%
 
%
%  
% adds option to set minimum number of observations within each region for
% search to take place
% minobs = min number of obs within region for search to take place
%           
%   
% uses Seo F test from Seo (2008) Econometric Theory paper
% (large sample Wald test) and associated bootstrapping algorithm
 
% added garch=0 if no garch, 1 if garch
 % Threshold cointegration routine on GLS-detrended or level  series
% Requires MFE toolbox for GARCH estimation
% JPV Econometrics toolbox for cols and rows operatorrs
% indicators for thresholds can be based on the lagged difference between y and
% the first column of x or on the lagged residual from the cointegrating
% regression, normalized on y
% input 
%       x   (can accomodate multiple regressors in cointegrating relationship)
% first column of x should be the series we use to subtract from y when
% calculating the indicator if we use the lagged price difference as the
% margin
%    
%       y   (variable on which cointegrating regression is normalized)
%      det  for GLS detrending ( 0 if constant, 1 if trend )
%      gls = 1 if you want Cook test, 0 for Enders- Siklos
%
%   
 

warning off;

disp('Max lags in ADF test')
pmax

disp('Max lags for threshold indicator ')
jcmax

disp('Max lags in  ECM ')
maxecmlag
  

% nboot number of bootstrap replications for F test
% bootstraps done by Block Bootstrapping according to SEO (2008) paper
%
% blocklen is the block length used in bootstrapping
% number of blocks is round {(samplesize - 1)/block length}
% 
%  
%  perc the percentage of total sample excluded from both ends of the threshold search
%  so entering 0.1 would involve threshold search from .1T to .9T
%  perc is entered as decimal eg .30    
%
% minobs is the min number of observations within a regime
%    
%  margin = 0  thresholds based on lagged difference between y and first
%                    column of x
%                    note if GLS=1 these differences are based on the GLS value of y minus the GLS
%                    value of the first column of x  
% margin = 1   thresholds based on lagged value of cointegrating regression residuals
%                    where the CR is normalized on y (or its GLS version) and includes a
%                    constant and x (or its GLS version, in which case there is no constant in 
%                    the cointegrating regression)


 
% pmax is max lag length of adf test
 % maxecmlag is the max lag of the changes in x and y in the ecm   


% jcmax is the maximum lag length for the indicator variable, min value = 2

% ecm = 0 if no constant in ecm, 1 otherwise
%
% *****only makes sense if GLS = 0
%
% jcmax is the maximum lag length for the indicator variable, min value = 2

%if jcmax>1
 

 if gls==0
     disp('Enders-Siklos test')
 else
     disp('Cook test')
 end
 
     if det==0
     disp('Test with constant')
     end
     if det==1
      disp('Test with trend')
     end
   if det==-1
     disp('Test without constant only valid if gls==0')
     end
 


if margin==1
    disp('TAR model. Thresholds based on lagged  cointegrating regression residual')
else
    disp('TAR model. Thresholds chosen on basis of lagged value of y minus x difference')
end

% 
% 

% 

% Follows approach of Gonzalo and Pitarakis 2002 JoE  
% estimate linear model and then one up to three threhsolds
% set up a model selection metric based on the aic or bic
%  
%  criterion = log(SSR) - lambda*(m+1)*k where m is the number of
%  thresholds, here m=[0,3]
%
%  lambda here is the BIC and equal to log(T) where T is the entire
%  sample size
% choose the number of thresholds that minimzes this criterion
% note this will NOT always be the one that maximizes the Seo F test
%  

pw=0;
fn=rows(x);
  
% first GLS detrend the series using constant (det=0) or trend (det=1)
% current version assumes detrending is the same (0 or 1) for all series
%
if gls==1
yd=glsd(y,det);
for pw=1:cols(x)
psx(:,pw)=glsd(x(:,pw),det);
end
xd=psx;
% 
%  if using GLS the thresholds are calculated as the glsd value of y less the glsd value of x,
% ie GLS value of Y minus GLS value of X
% 
% 
%%%%%%%%%%%%%%%%%%%%  
 
% create the difference between y and the first column of x on gls data
 
differe=yd-xd(:,1);
 

% lag once because the threshold is determined by the indicator variable
% based on the lagged price difference 


diffd=differe(1:rows(differe)-1,1);




end
 
if gls==0
    % if not GLS then simply use the level series
    
    yd=y;
  
% x does not include a constant so add one
% jan 11 2012 added trend to non cook test
if det==0
 xd=horzcat(x,ones(rows(x),1));
end
if det==1
 xd=horzcat(x,ones(rows(x),1),(1:1:rows(x))');   
end
if det==-1
    xd=x;
end

% create the price difference on gls data
 
differe=yd-xd(:,1);

% lag once because the threshold is determined by the indicator variable




diffd=differe(1:rows(differe)-1,1);
 




end
 
 observ=rows(diffd);
 
% run cointegrating regression on GLS-detrended or actual series
% obtain residuals and create their lag
% residuals from obs 1 to T
 
% aug 2012ehatw=yd-xd*(xd\yd);
% horzcat(yd,xd)
% %pause
ehatw=yd-xd*(xd\yd);
disp('cr coefficients')
xd\yd
rows(ehatw)
rows(yd)
%pause
 
 
disp('betahat vector from cointegrating regression')
xd\yd
 %%pause
% create lagged cointegrating regression residual and difference between
% the current and lagged cointegrating regression residual from obs 1 to T
%fehatlw=lag(ehatw) ;

ehatlw=ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
dehatw=ehatw(2+pmax+jcmax:rows(ehatw),1)-ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
wood=horzcat(ehatlw,dehatw);
 
%  now calculate F test using OLS covariance matrix assuming no
%  thresholds

% dehatw is the change in the CR residuals, ehatlw is the lagged CR
% residual
beta=[inv(ehatlw'*ehatlw)]*(ehatlw'*dehatw);
[a,b]=size(ehatlw) ;
% create residuals
 res=dehatw-ehatlw*beta;
 
% create SSR
 ssra=res'*res;
  
  
 %
 %disp('No threshold sigmahat')
 sigmahat=ssra/(a);
 topsig=sigmahat;
    


  
% look at the ordinary OLS F test without
 
%

disp('F test for lagged residual equal zero, OLS cov matrix');
 
disp('F test is T ((ssru/ssrr) - 1 )');
F2=a*(( (dehatw'*dehatw)/(res'*res) )-1)
%%%%pause

disp('ADF version (min bic) of test for lagged residual equal zero');
 

 bigt=rows(dehatw); 
nobs10=bigt;
% lags 0
 
    X=ehatlw;

 
    y=dehatw;
beta2=[inv(X'*X)]*(X'*y) ;
[a,b]=size(X) ;
  res=y-X*beta2;
   ssrt=res'*res/(rows(X));
 R=eye(cols(X))';
 r=zeros(cols(X),1);
 vhat=X'*X\eye(cols(X));
sigmahat(1)=ssrt;
 ssrg(1)=res'*res;
 topsig;
  botsig=res'*res/rows(res);
  %%%%pause
 F(1,1)=a*(( (dehatw'*dehatw)/(res'*res) )-1);
  
bic(1,1)=(log(ssrt))+(log(rows(y))*cols(X)/rows(y));

ssrt(1)=ssrt;
if pmax>0    
    
     
    % prewhitening: multiple regression with p lags
    X=ehatlw;    
    for i=1:1:pmax
        X = [X ehatw(2+pmax+jcmax-i:rows(ehatw)-i,1)-ehatw(1+pmax+jcmax-i:rows(ehatw)-1-i,1) ];
     Xg= X(:,2:i+1);
   
        y=dehatw;
        
        
beta9=X\y;
 beta9d=Xg\y;
[a,b]=size(X) ;
  res9=y-X*beta9;
  res9d=y-Xg*beta9d;
   ssrt9=res9'*res9/(rows(X));
 Rf=horzcat(eye(1),zeros(1,i));
 rf=zeros(1,1);
 vhat=X'*X\eye(cols(X));
sigmahat(i+1)=ssrt9;
results1=olsp(y,X);
 ssrg(i+1)=res9'*res9;
 ssrt(i+1)=ssrt9;
  botsig=res9'*res9/rows(res9);
  F(i+1,1)=rows(y)*(((res9d'*res9d)/(res9'*res9))-1);
 t=results1.tstat;
beta=results1.beta;
bic(i+1,1)= (log(ssrt9))+(log(bigt)*cols(X)/rows(X));
   end
end
 horzcat(bic,F);
[aj1,aj2]=min(bic);

bicvalue=bic(aj2);
F3=F(aj2)
sigmahatt=sigmahat(aj2);
     totalcols=2;
  %totalcols=2+aj2-1;
disp('lag in ADF test')
aj2-1
%%%%pause

 
disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
 disp('Begin Threshold Search')
disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
 
% % 

% 
%  Real Seo test search
% no threshold variance includes lagged cr residual but not in thresholds
% used in gonpit model selection metric
   ehatvar=ehatw(1+pmax:rows(ehatw)-1,1);
dehatw1=ehatw(2+pmax:rows(ehatw),1)-ehatw(1+pmax:rows(ehatw)-1,1);
  rnoth=dehatw1-ehatvar*(ehatvar\dehatw1);
  restrictedssr= (rnoth'*rnoth)/rows(rnoth);

 
%here
jc=-1; 
for infolag=1:jcmax-1
 jc=jc+1;
 
 % create data
  diffd1=differe(1+pmax+jcmax-jc:rows(differe)-1-jc,1);
 ehatvar=ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
  ehatlw=ehatw(1+pmax+jcmax-jc:rows(ehatw)-1-jc,1);
%  disp('aug 15 rows ehatlw')
%  rows(ehatlw)
%  rows(ehatvar)
%  pause
%  
  dehatw1=ehatw(2+pmax+jcmax:rows(ehatw),1)-ehatw(1+pmax+jcmax:rows(ehatw)-1,1);

 [bestf1r,tauvals1r,besttt1r,adflag1r,bestbetas1r,seobic1r]=one(jc,ehatw,differe,perc,margin,jcmax,pmax,minobs,ngrid);
%[bestf1r,tauvals1r,besttt1r,adflag1r,bestbetas1r,seobic1r]=findonefridayorig(jc,ehatw,differe,perc,margin,jcmax,pmax,minobs,ngrid);

 bestf11(infolag,1)=bestf1r;
 besttauvals11(infolag,:)=tauvals1r;
 
 besttt11(infolag,:)=besttt1r;
 bestadflag11(infolag,1)=adflag1r;
 bestbetas11(infolag,:)=bestbetas1r;
 bestseobic11(infolag,1)=seobic1r;
adflag11(infolag,1)=adflag1r;
  firstt=tauvals1r;
  if margin==0
           
    % for i=1:1:rows(diffd1)
 
           aregre1=(diffd1<=firstt).*ehatvar;
           aregre2=(diffd1>firstt).*ehatvar;
             
 
 end
     
  
            if margin==1

           aregre1=(ehatlw<=firstt).*ehatvar;
           aregre2=(ehatlw>firstt).*ehatvar;
         
            end
% if margin==0
%             
% for i=1:1:rows(diffd1)
%  if diffd1(i,1)<=firstt
%         qindp1(i,1)=1;
%  else
%         qindp1(i,1)=0;
%  end
% end
%  end  
%             if margin==1
% for i=1:1:rows(ehatlw)
%      if ehatlw(i,1)<=firstt
%         qindp1(i,1)=1;
%      else
%         qindp1(i,1)=0;
%      end
%      
% end
%             end   
%             aregre1=qindp1.*ehatvar;
%             aregre2=(1-qindp1).*ehatvar;   
 mpeterabcd=horzcat(aregre1,aregre2);
 
% 
 mpeterabcd5=horzcat(aregre1,aregre2);

 if adflag1r==0
     resvarx=dehatw1-mpeterabcd*(mpeterabcd\dehatw1);
resvar75a=resvarx;
 end
 if adflag1r>0    
    X1=mpeterabcd;
    for ir=1:1:adflag1r
        X1 = [X1 ehatw(2+pmax+jcmax-ir:rows(ehatw)-ir,1)-ehatw(1+pmax+jcmax-ir:rows(ehatw)-1-ir,1)];
    end
        y=dehatw1;
   resvarx=y-X1*(X1\y);
   resvar75a=resvarx;
 end
 
 
 
 %###################################################
 %  now construct the Gonpit-type model selection criterion  (28)
 %
 %    log(no threshold variance/threshold variance) - penalty term
 %bic2
 %
 %###################################################
 unrestrictssr=(resvar75a'*resvar75a)/rows(resvar75a);
 % bic penalty is log(T)
 m=1;
 k=1;
  
 if lambda==2
 % 
 %gonpit0 is no threshold case so m=1
    gonpit00=log(restrictedssr)+ (2*log(rows(rnoth))*(1)*k/rows(rnoth)); 

     gonpit10= log(unrestrictssr) + (2*log(rows(rnoth))*(m+1)*k/rows(rnoth)); 
 end
     
 if lambda==1
 % 
 %gonpit0 is no threshold case so m=1
    gonpit00=log(restrictedssr)+ (log(rows(rnoth))*(1)*k/rows(rnoth)); 

     gonpit10= log(unrestrictssr) + (log(rows(rnoth))*(m+1)*k/rows(rnoth)); 
 end
 % aic penalty is lambda=2
 if lambda==0
     %gonpit0 is no threshold case so m=0
    gonpit00=log(restrictedssr)+ (2*(1)*k/rows(rnoth)); 
 
 gonpit10= log(unrestrictssr) + (2*(m+1)*k/rows(rnoth));
 
 
  
 end

 
 
 
 
 
 
 

 [bestf1a,tauvals1a,besttt1a,adflag1a,bestbetas1a,seobic1a]=two(jc,ehatw,differe,perc,margin,jcmax,pmax,minobs,ngrid);
%[bestf1a,tauvals1a,besttt1a,adflag1a,bestbetas1a,seobic1a]=findtwofridayorig(jc,ehatw,differe,perc,margin,jcmax,pmax,minobs,ngrid);
 
  
 

 bestf22(infolag,1)=bestf1a;
 besttauvals2(infolag,:)=tauvals1a;
   
 
 
 besttt2s(infolag,:)=besttt1a;
 bestadflag2(infolag,1)=adflag1a;
 bestbetas2s(infolag,:)=bestbetas1a;
 
 bestseobic2(infolag,1)=seobic1a;
adflag2(infolag,1)=adflag1a;
  

teert=(tauvals1a');
 
 
seconda=teert(1,1);

firstt=teert(2,1);

%  if margin==0
%             
% for i=1:1:rows(diffd1)
%  if diffd1(i,1)<=seconda
%         aregre1(i,1)=ehatvar(i,1);
%         qindp1(i,1)=1;
%     else
%         aregre1(i,1)=0;
%         qindp1(i,1)=0;
%  end
%     if seconda<diffd1(i,1) && diffd1(i,1)<=firstt
%         aregre2(i,1)=ehatvar(i,1);
%         qindp2(i,1)=1;
%     else
%         aregre2(i,1)=0;
%         qindp2(i,1)=0;
%     end
%      
%     if diffd1(i,1)>firstt
%         aregre3(i,1)=ehatvar(i,1);
%         qindp3(i,1)=1;
%     else
%         aregre3(i,1)=0;
%         qindp3(i,1)=0;
%     end
% end
%  end  
%      
%  
%  
 
%             if margin==1
% for i=1:1:rows(ehatlw)
%      if ehatlw(i,1)<=seconda
%         aregre1(i,1)=ehatvar(i,1);
%         qindp1(i,1)=1;
%     else
%         aregre1(i,1)=0;
%         qindp1(i,1)=0;
%      end
%     if seconda<ehatlw(i,1) && ehatlw(i,1)<=firstt
%         aregre2(i,1)=ehatvar(i,1);
%         qindp2(i,1)=1;
%     else
%         aregre2(i,1)=0;
%         qindp2(i,1)=0;
%     end
%     if ehatlw(i,1)>firstt
%         aregre3(i,1)=ehatvar(i,1);
%         qindp3(i,1)=1;
%     else
%         aregre3(i,1)=0;
%         qindp3(i,1)=0;
%     end
% end
%             end
              if margin==0
           
    % for i=1:1:rows(diffd1)
 
           aregre1=(diffd1<=seconda).*ehatvar;
           
           aregre2=((diffd1>seconda)&(diffd1<=firstt)).*ehatvar;
           aregre3=(diffd1>firstt).*ehatvar;  
            
 
 end
     
  
            if margin==1

           aregre1=(ehatlw<=seconda).*ehatvar;
      aregre2=((ehatlw>seconda)&(ehatlw<=firstt)).*ehatvar;
           aregre3=(ehatlw>firstt).*ehatvar;  
         
            end
             
         
 mpeterabcd=horzcat(aregre1,aregre2,aregre3);
 
% 
 mpeterabcd5=horzcat(aregre1,aregre2,aregre3);

 if adflag1a==0
     resvarx=dehatw1-mpeterabcd*(mpeterabcd\dehatw1);
resvar75b=resvarx;
 end
 if adflag1a>0    
    X1=mpeterabcd;
    for ir=1:1:adflag1a
        X1 = [X1 ehatw(2+pmax+jcmax-ir:rows(ehatw)-ir,1)-ehatw(1+pmax+jcmax-ir:rows(ehatw)-1-ir,1)];
    end
    disp('two thresholds aug 15 x matrix')
    rows(X1)
    X1(1:10,:)
    %pause
        y=dehatw1;
   resvarx=y-X1*(X1\y);
   resvar75b=resvarx;
 end
 
 
 
 %###################################################
 %  now construct the Gonpit-type model selection criterion  (28)
 %
 %    log(no threshold variance/threshold variance) - penalty term
 %
 %
 %###################################################
 unrestrictssr=(resvar75b'*resvar75b)/rows(resvar75b);
 % bic penalty is log(T)
 m=2;
 k=1;
 if lambda==2
 %disp('gonpit criterion using bic is')
  
     gonpit20= log(unrestrictssr) + ((2*log(rows(rnoth))*(m+1)*k/rows(rnoth)));
 end
 
 if lambda==1
 %disp('gonpit criterion using bic is')
  
     gonpit20= log(unrestrictssr) + ((log(rows(rnoth))*(m+1)*k/rows(rnoth)));
 end
 
 % aic penalty is 2
 if lambda==0
 gonpit20= log(unrestrictssr) + (2*(m+1)*k/rows(rnoth));
 %disp('gonpit criterion using aic is')
 
 
 end
%%%%%%%%%%  find third fast
 
 [bestf3r,tauvals3r,besttt3r,adflag3r,bestbetas3r,seobic3r]=three(jc,ehatw,differe,perc,margin,jcmax,pmax,minobs,ngrid);
%  [bestf3r,tauvals3r,besttt3r,adflag3r,bestbetas3r,seobic3r]=quick3estimate(jc,ehatw,differe,perc,margin,jcmax,pmax,minobs,ngrid,maxip);
 
 
  
 bestf113(infolag,1)=bestf3r;
 besttauvals113(infolag,:)=tauvals3r;
  
%  bestbetas3r=bestbetas3r(any(bestbetas3r,2),:);
%  besttt3r=besttt3r(any(besttt3r,2),:);
%  
 besttt113(infolag,:)=besttt3r;
 bestadflag113(infolag,1)=adflag3r;
 bestbetas113(infolag,:)=bestbetas3r;
 bestseobic113(infolag,1)=seobic3r;
adflag113(infolag,1)=adflag3r;
 


tgr=(tauvals3r)';
%Feb 20 change
seconda=tgr(1,1);
firstt=tgr(2,1);
secondb=tgr(3,1);

 
% 
%  if margin==0
%             
% for i=1:1:rows(diffd1)
%  if diffd1(i,1)<=seconda
%         aregre1(i,1)=ehatvar(i,1);
%         qindp1(i,1)=1;
%     else
%         aregre1(i,1)=0;
%         qindp1(i,1)=0;
%  end
%     if seconda<diffd1(i,1) && diffd1(i,1)<=firstt
%         aregre2(i,1)=ehatvar(i,1);
%         qindp2(i,1)=1;
%     else
%         aregre2(i,1)=0;
%         qindp2(i,1)=0;
%     end
%     if firstt<diffd1(i,1) && diffd1(i,1)<=secondb
%         aregre3(i,1)=ehatvar(i,1);
%         qindp3(i,1)=1;
%     else
%         aregre3(i,1)=0;
%         qindp3(i,1)=0;
%     end
%     if diffd1(i,1)>secondb
%         aregre4(i,1)=ehatvar(i,1);
%         qindp4(i,1)=1;
%     else
%         aregre4(i,1)=0;
%         qindp4(i,1)=0;
%     end
% end
%  end  
     
 
 
%  
%             if margin==1
% for i=1:1:rows(ehatlw)
%      if ehatlw(i,1)<=seconda
%         aregre1(i,1)=ehatvar(i,1);
%         qindp1(i,1)=1;
%     else
%         aregre1(i,1)=0;
%         qindp1(i,1)=0;
%      end
%     if seconda<ehatlw(i,1) && ehatlw(i,1)<=firstt
%         aregre2(i,1)=ehatvar(i,1);
%         qindp2(i,1)=1;
%     else
%         aregre2(i,1)=0;
%         qindp2(i,1)=0;
%     end
%     if firstt<ehatlw(i,1) && ehatlw(i,1)<=secondb
%         aregre3(i,1)=ehatvar(i,1);
%         qindp3(i,1)=1;
%     else
%         aregre3(i,1)=0;
%         qindp3(i,1)=0;
%     end
%     if ehatlw(i,1)>secondb
%         aregre4(i,1)=ehatvar(i,1);
%         qindp4(i,1)=1;
%     else
%         aregre4(i,1)=0;
%         qindp4(i,1)=0;
%     end
% end
%             end
             
         if margin==0
           
    % for i=1:1:rows(diffd1)
 
           aregre1=(diffd1<=seconda).*ehatvar;
           aregre2=((diffd1>seconda)&(diffd1<=firstt)).*ehatvar;
          % aregre2=(seconda<diffd1<=firstt).*ehatvar;
        %   aregre3=(firstt<diffd1<=secondb).*ehatvar;  
           aregre3=((diffd1>firstt)&(diffd1<=secondb)).*ehatvar;
           aregre4=(diffd1>secondb).*ehatvar;
 
 end
     
  
            if margin==1

           aregre1=(ehatlw<=seconda).*ehatvar;
%            aregre2=(seconda<ehatlw<=firstt).*ehatvar;
%            aregre3=(firstt<ehatlw<=secondb).*ehatvar;  
aregre2=((ehatlw>seconda)&(ehatlw<=firstt)).*ehatvar;
 aregre3=((ehatlw>firstt)&(ehatlw<=secondb)).*ehatvar;
           aregre4=(ehatlw>secondb).*ehatvar;
            end
             

 mpeterabcd=horzcat(aregre1,aregre2,aregre3,aregre4);
 
% 
 mpeterabcd5=horzcat(aregre1,aregre2,aregre3,aregre4);

 if adflag3r==0
     resvarx=dehatw1-mpeterabcd*(mpeterabcd\dehatw1);
resvar75=resvarx;
 end
 if adflag3r>0    
    X1=mpeterabcd;
    for ir=1:1:adflag3r
        X1 = [X1 ehatw(2+pmax+jcmax-ir:rows(ehatw)-ir,1)-ehatw(1+pmax+jcmax-ir:rows(ehatw)-1-ir,1)];
    end
        y=dehatw1;
   resvarx=y-X1*(X1\y);
   resvar75=resvarx;
 end
 
 
 
 %###################################################
 %  now construct the Gonpit-type model selection criterion  (28)
 %
 %    log(no threshold variance/threshold variance) - penalty term
 %
 %
 %###################################################
 unrestrictssr=(resvar75'*resvar75)/rows(resvar75);
 % bic penalty is log(T)
 m=3;
 k=1;
 if lambda==2
 %disp('gonpit criterion using bic is')
 
     gonpit30= log(unrestrictssr) + (2*log(rows(rnoth))*(m+1)*k/rows(rnoth));
 %gonpit3
 % aic penalty is 2
 end
 
 if lambda==1
 %disp('gonpit criterion using bic is')
 
     gonpit30= log(unrestrictssr) + (log(rows(rnoth))*(m+1)*k/rows(rnoth));
 %gonpit3
 % aic penalty is 2
 end
 if lambda==0
 gonpit30= log(unrestrictssr) + (2*(m+1)*k/rows(rnoth));
 
% disp('gonpit criterion using bic is')
 %gonpit3
 
 end
 
 infolagin=infolag;
 if bestf11(infolag,1)~=0 && bestf22(infolag,1)~=0 && bestf113(infolag,1)~=0
 
 
 
 gonpits1=horzcat(infolagin,gonpit00,gonpit10,gonpit20,gonpit30);
 criter(infolag,1:5)=gonpits1;
if gonpit30==min(gonpits1(1,2:5))
     disp('three thresholds')
     
     tauvalex(infolag,1:3)=besttauvals113(infolag,1:3);
%     tauvars=besttauvals3';
%    sorr=sort(tauvars);
% firstt = sorr(2,1);
% seconda = sorr(1,1);
% secondb = sorr(3,1);
 end
     if gonpit20==min(gonpits1(1,2:5))
  disp('two thresholds')
   
  tauvalex(infolag,1:3)=horzcat(besttauvals2(infolag,1:2),0);
%     tauvars=besttauvals2b';
%    sorr1=sort(tauvars);
% firstt = sorr1(2,1);
% seconda = sorr1(1,1);
% secondb=-999999999999;
     end
 
    if gonpit10==min(gonpits1(1,2:5))
  disp('one thresholds')
  
  tauvalex(infolag,1:3)=horzcat(besttauvals11(infolag,1),zeros(1,2));
%  firstt = besttauvals1 ;
% seconda=888888888888;
% secondb=-999999999999;
    end
    if gonpit00==min(gonpits1(1,2:5))
  disp('no thresholds')
   
  tauvalex(infolag,1:3)=zeros(1,3);
%  firstt = 999999 ;
% seconda = 888888888888;
% secondb=-999999999999;
    end
    
     
    
    % must eliminate those infolags for which the F test was not done !
    
 else
     tauvalex(infolag,1:3)=zeros(1,3);
  criter(infolag,1:5)=horzcat(infolag,99999,99999,99999,99999);
end
end
format long
 criter
 tauvalex
 [value, index] = min(reshape(criter(:,2:5), numel(criter(:,2:5)), 1));
[ii,j] = ind2sub(size(criter(:,2:5)), index)
 

tauvalex(ii,:)
toc
ii
j

 i=criter(ii,1)
 




bestjclag=i-1;
numtau=j;
if numtau==2
    firstt=besttauvals11(i,1)
    bestf1=bestf11(i,1);
    adflag1=adflag11(i,1);
    bestbetas1=bestbetas11(i,:);
    bestt1=besttt11(i,:);
  
end
if numtau==3
   rt=besttauvals2(i,1:2)';
   firstt=rt(2,1)
   seconda=rt(1,1)
   disp('aug 15 thresholds')
   %pause
    bestf2=bestf22(i,1);
    adflag2=bestadflag2(i,1);
    bestbetas2=bestbetas2s(i,:);
    bestt2=besttt2s(i,:);
  
end
    if numtau==4
        ft=besttauvals113(i,1:3)';
        rt=(ft');
        %feb 20 change
        seconda=rt(1);
        firstt=rt(2);
        secondb=rt(3);
        bestf3=bestf113(i,1);
        adflag3=bestadflag113(i,1);
        bestbetas3=bestbetas113(i,:);
        bestt3=besttt113(i,:);
         
    end
   %%%pause
        
% one threshold
 %[bestf,tauvals,bestinfolag,besttt,adflag,bestbetas,seobic,gregg,thresholdvar1]=realseoone(ehatw,differe,det,gls,numm,newey,perc,margin,nboot,blocklen,jcmax,pmax,minobs);
  
 %%%%pause
 
 
 
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
disp(' given thresholds that were found now estimate the ecm and bootstrap the tests') 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%
%%%%%%%   if there are three thresholds do the tests
if numtau==4
%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %  
tic
disp('Three thresholds found')
%##########################################################
% name the threshold values
% 
threshold1 = firstt
thresholdbelowfirstt = seconda
thresholdabovefirstt = secondb
disp('thresholdbelowfirst should be below  threshold1 should be below thresholdabovefirstt')
%%%pause
% 
 
% check to ensure at least minobs in each subregion
jc=bestjclag;
firstc=jc;
diffd1=differe(1+pmax+jcmax-jc:rows(differe)-1-jc,1);
ehatvar=ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
 ehatlw=ehatw(1+pmax+jcmax-jc:rows(ehatw)-1-jc,1);
 dehatw1=ehatw(2+pmax+jcmax:rows(ehatw),1)-ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
 
 
 
 
 
 
  %%%%pause

disp('Seo F test ')
bestf3;
newtestval=bestf3;
   if margin==0
      ;
 n11=fix(perc*(rows(diffd1)));
n12=fix((1-perc)*(rows(diffd1)));
scrit=sort(diffd1);
ed1=(scrit(n12,1)-scrit(n11,1))/ngrid;
    thresh3a=(scrit(n11,1):ed1:scrit(n12-2*minobs,1))';
    thresh3e=(scrit(n11+minobs,1):ed1:scrit(n12-minobs,1))';
    thresh3b=(scrit(n11+(2*minobs),1):ed1:scrit(n12,1))';
    
   else
  n11=fix(perc*(rows(ehatlw)));
n12=fix((1-perc)*(rows(ehatlw)));
scrit=sort(ehatlw);
ed1=(scrit(n12,1)-scrit(n11,1))/ngrid;
    thresh3a=(scrit(n11,1):ed1:scrit(n12-2*minobs,1))';
    thresh3e=(scrit(n11+minobs,1):ed1:scrit(n12-minobs,1))';
    thresh3b=(scrit(n11+(2*minobs),1):ed1:scrit(n12,1))';
                  
   end
  

 
% 
%  if margin==0
%             
% for i=1:1:rows(diffd1)
%  if diffd1(i,1)<=seconda
%         aregre1(i,1)=ehatvar(i,1);
%         qindp1(i,1)=1;
%     else
%         aregre1(i,1)=0;
%         qindp1(i,1)=0;
%  end
%     if seconda<diffd1(i,1) && diffd1(i,1)<=firstt
%         aregre2(i,1)=ehatvar(i,1);
%         qindp2(i,1)=1;
%     else
%         aregre2(i,1)=0;
%         qindp2(i,1)=0;
%     end
%     if firstt<diffd1(i,1) && diffd1(i,1)<=secondb
%         aregre3(i,1)=ehatvar(i,1);
%         qindp3(i,1)=1;
%     else
%         aregre3(i,1)=0;
%         qindp3(i,1)=0;
%     end
%     if diffd1(i,1)>secondb
%         aregre4(i,1)=ehatvar(i,1);
%         qindp4(i,1)=1;
%     else
%         aregre4(i,1)=0;
%         qindp4(i,1)=0;
%     end
% end
%  end  
%      
%  
%  
%  
%             if margin==1
% for i=1:1:rows(ehatlw)
%      if ehatlw(i,1)<=seconda
%         aregre1(i,1)=ehatvar(i,1);
%         qindp1(i,1)=1;
%     else
%         aregre1(i,1)=0;
%         qindp1(i,1)=0;
%      end
%     if seconda<ehatlw(i,1) && ehatlw(i,1)<=firstt
%         aregre2(i,1)=ehatvar(i,1);
%         qindp2(i,1)=1;
%     else
%         aregre2(i,1)=0;
%         qindp2(i,1)=0;
%     end
%     if firstt<ehatlw(i,1) && ehatlw(i,1)<=secondb
%         aregre3(i,1)=ehatvar(i,1);
%         qindp3(i,1)=1;
%     else
%         aregre3(i,1)=0;
%         qindp3(i,1)=0;
%     end
%     if ehatlw(i,1)>secondb
%         aregre4(i,1)=ehatvar(i,1);
%         qindp4(i,1)=1;
%     else
%         aregre4(i,1)=0;
%         qindp4(i,1)=0;
%     end
% end
%             end
              if margin==0
             aregre1=(diffd1<=seconda).*ehatvar;
           aregre2=((diffd1>seconda)&(diffd1<=firstt)).*ehatvar;
          % aregre2=(seconda<diffd1<=firstt).*ehatvar;
        %   aregre3=(firstt<diffd1<=secondb).*ehatvar;  
           aregre3=((diffd1>firstt)&(diffd1<=secondb)).*ehatvar;
           aregre4=(diffd1>secondb).*ehatvar;
    % for i=1:1:rows(diffd1)
 qindp1=(diffd1<=seconda);
 qindp2=(diffd1>seconda)&(diffd1<=firstt);
 qindp3=(diffd1>firstt)&(diffd1<=secondb);
 qindp4=(diffd1>secondb);
%            aregre1=(diffd1<=seconda).*ehatvar;
%            aregre2=(seconda<diffd1<=firstt).*ehatvar;
%            aregre3=(firstt<diffd1<=secondb).*ehatvar;  
%            aregre4=(diffd1>secondb).*ehatvar;
 
 end
     
  
            if margin==1
%  qindp1=(ehatlw<=seconda);
%  qindp2=(seconda<ehatlw<=firstt);
%  qindp3=(firstt<ehatlw<=secondb);
%  qindp4=(ehatlw>secondb);
%            aregre1=(ehatlw<=seconda).*ehatvar;
%            aregre2=(seconda<ehatlw<=firstt).*ehatvar;
%            aregre3=(firstt<ehatlw<=secondb).*ehatvar;  
%            aregre4=(ehatlw>secondb).*ehatvar;
%          
             aregre1=(ehatlw<=seconda).*ehatvar;
           aregre2=((ehatlw>seconda)&(ehatlw<=firstt)).*ehatvar;
          % aregre2=(seconda<diffd1<=firstt).*ehatvar;
        %   aregre3=(firstt<diffd1<=secondb).*ehatvar;  
           aregre3=((ehatlw>firstt)&(ehatlw<=secondb)).*ehatvar;
           aregre4=(ehatlw>secondb).*ehatvar;
    % for i=1:1:rows(diffd1)
 qindp1=(ehatlw<=seconda);
 qindp2=(ehatlw>seconda)&(ehatlw<=firstt);
 qindp3=(ehatlw>firstt)&(ehatlw<=secondb);
 qindp4=(ehatlw>secondb);
            
            
            end
            numbelow1=aregre1;
            numbelow1(numbelow1==0)=[];
           smplbelow1=rows(numbelow1);
            
            numbelow2=aregre2;
            numbelow2(numbelow2==0)=[];
           smplbelow2=rows(numbelow2);
         
            numbelow3=aregre3;
            numbelow3(numbelow3==0)=[];
           smplbelow3=rows(numbelow3);
            
            numbelow4=aregre4;
            numbelow4(numbelow4==0)=[];
           smplbelow4=rows(numbelow4);
         
           disp('observations within each region')
           disp('below lowest threshold')
           smplbelow1
       
           disp('between lowest threshold and the middle')
           smplbelow2
           
           disp('between the middle and the highest threshold')
           smplbelow3
           
           disp('above the highest  threshold')
           smplbelow4
           
           disp('total sample is ')
           rows(dehatw1)
           disp('sum of subregions is')
           smplbelow1+smplbelow2+smplbelow3+smplbelow4
           
           %%%%pause
           
           
 mpeterabcd=horzcat(aregre1,aregre2,aregre3,aregre4);
 
% 
 mpeterabcd5=horzcat(aregre1,aregre2,aregre3,aregre4);

 if adflag3==0
     resvarx=dehatw1-mpeterabcd*(mpeterabcd\dehatw1);
resvar75q=resvarx;
 end
 if adflag3>0    
    X1=mpeterabcd;
    for ir=1:1:adflag3
        X1 = [X1 ehatw(2+pmax+jcmax-ir:rows(ehatw)-ir,1)-ehatw(1+pmax+jcmax-ir:rows(ehatw)-1-ir,1)];
    end
        y=dehatw1;
   resvarx=y-X1*(X1\y);
   resvar75q=resvarx;
 end
  

 
 
 
 yj2=adflag3;
 
 
 
 


disp('three thresholds')
%%%%pause
gfbetsas=bestbetas3';
gfbetsas(gfbetsas==0)=[];
gfts=bestt3';
gfts(gfts==0)=[];

 disp('f test for coefficients on lagged residuals above and below thresholds jointly zero')
newtestval
 disp('coefficients and their t tests for null of zero')
 disp('first coeff, below the lowest threshold')
 vertcat(gfbetsas(1,1),gfts(1,1))
 disp('second coeff, above the lowest threshold')
 vertcat(gfbetsas(2,1),gfts(2,1))
disp('coefficients and their t tests for null of zero')
 disp('third coeff, below the highest threshold')
 vertcat(gfbetsas(3,1),gfts(3,1))
 disp('second coeff, above the highest threshold')
 vertcat(gfbetsas(4,1),gfts(4,1))

 
 
 figure(90145)
%       
tau1=firstt.*ones(rows(ehatw),1); 
  tau2=seconda.*ones(rows(ehatw),1);
 tau3=secondb.*ones(rows(ehatw),1);
 
% tau2=seconda.*ones(rows(ehatw),1);
        hold on
 plot(tau1,'-c')
  plot(tau2,'-r')
  plot(tau3,'-g')
  %march 12 12
 if margin==0
 plot(ehatvar,'-g')
 end
 if margin==1
     plot(ehatvar,'-g')
 end
 %march 12/12
  % replaced above march 12/12 plot(ehatw,'-b')
  hold off 
 
 

     disp('lag length in ADF test version')
    adflag3
     wfred=rows(gfbetsas);
 % write out ADF lagged dependent variable version if newey=2
 if wfred>4
 gfbetsas
 gfts
     for i=5:rows(gfbetsas)
    
disp('Testing equation, lagged change in CR ADF coefficients and t')
 vertcat(gfbetsas(i,1),gfts(i,1))
 end
 end
  
   
          
   
   
   % &&&&&&&
   %%%%%% start new ecm
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%% Estimate ECM 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % Reset indreg12w because in line 817 is built up with lags 
 % indpss = 1 if indicator <= threshold
 % run CR regression to get residuals
 % sept 12 ehatw=yd-xd*(xd\yd);
 ehatw=yd-xd*(xd\yd);
 % lag those residuals and use chosen jc 
 %gee
 
ehatlw=ehatw(1+pmax+jcmax-jc:rows(ehatw)-1-jc,1);

%december 2011
ehatvariable=ehatw(1+pmax+jcmax:rows(ehatw)-1,1);




eresids1=qindp1.*ehatvariable;
eresids2=qindp2.*ehatvariable;
eresids3=qindp3.*ehatvariable;
eresids4=qindp4.*ehatvariable;
% put lagged CR residuals together
rhsv=horzcat(eresids1,eresids2,eresids3,eresids4);
% resids1=indpss.*ehatlw;
% resids2=(1.0-indpss).*ehatlw;
% eddie=horzcat(indpss,1.0-indpss);
% eddie(1:20,:)
% % put lagged CR residuals together
% rhsv=horzcat(resids1,resids2);
% create delta X and delta Y for ECM
newyd=yd(2+pmax+jcmax:rows(differe),1);
 dnewyd=yd(2+pmax+jcmax:rows(differe),1)-yd(1+pmax+jcmax:rows(differe)-1,1);;
 % note only picks out first column of x
 % if x contains more than 1 vbl then need to adjust code below
 %
 if cols(x)==1
 % orig below
     newxd=xd(1+pmax+jcmax:rows(differe),1);
 dnewxd=xd(2+pmax+jcmax:rows(differe),1)-xd(1+pmax+jcmax:rows(differe)-1,1);;
% original above
 else
 newxd=xd(1+pmax+jcmax:rows(differe),1:cols(x));
 dnewxd=xd(2+pmax+jcmax:rows(differe),1:cols(x))-xd(1+pmax+jcmax:rows(differe)-1,1:cols(x));;
 end
     
 yvar1=dnewyd(1+maxecmlag:rows(dnewyd),1);
 xvar1=dnewxd(1+maxecmlag:rows(dnewxd),1);
 % no lags
 
  if gls==0 && ecm==1
 rhsv1=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:)) ;
 else
 rhsv1=rhsv(1+maxecmlag:rows(rhsv),:);
 end
  results=nwestpss(yvar1,rhsv1,round(rows(yvar1)^.25));
 % disp('here july 25')
 %%%%pause
 
 % 
 disp('ecm estimates assuming no lagged changes in x and y, both set to be the same')
 
 
  if gls==0 && ecm==1
 xnew=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:));
  else
      xnew=rhsv(1+maxecmlag:rows(rhsv),:);
  end
 % no lags in ecm
 %results=ols(yvar1,indreg12wnew);
   
 bicnew(1)= (log((results.resid'*results.resid)/rows(results.resid)))+(log(rows(yvar1))*cols(rhsv1)/rows(yvar1));
 for j=1:rows(results.beta)
 vertcat(results.beta(j),results.tstat(j))
 end
 % lags 1 to maxecmlag
 for i=1:maxecmlag
    xnew=[xnew dnewxd(1+maxecmlag-i:rows(dnewxd)-i,:),dnewyd(1+maxecmlag-i:rows(dnewyd)-i,1)];
   results=nwestpss(yvar1,xnew,round(rows(yvar1)^.25));
 
%  %%%%pause  
%    
   bicnew(i+1)= (log((results.resid'*results.resid )/rows(results.resid)))+(log(rows(yvar1))*cols(xnew)/rows(yvar1)); 
 end
 [pet1,pet2]=min(bicnew);
 %sort(bicnew)'
 disp('best lag length in ecm is ')
 pet2-1
 

if gls==0 && ecm==1
   xnewa=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:));
else
  xnewa=rhsv(1+maxecmlag:rows(rhsv),:);
end
  for i=1:pet2-1
        xnewa=[xnewa dnewxd(1+maxecmlag-i:rows(dnewxd)-i,:),dnewyd(1+maxecmlag-i:rows(dnewyd)-i,1)];
    end
   resultsa=nwestpss(yvar1,xnewa,round(rows(yvar1)^.25));
   
  %JMM added plot 
  figure(1)
  subplot(4,1,4)
  if gls==0 && ecm==1
  plot(rhsv1(:,2))
  else
      plot(rhsv1(:,1))
  end
    title('Lagged CR in region A')
  
    subplot(4,1,3)
  if gls==0 && ecm==1
      plot(rhsv1(:,3))
  else
      plot(rhsv1(:,2))
  end
    title('Lagged CR in region B')
  
    subplot(4,1,2)
  if gls==0 && ecm==1
      plot(rhsv1(:,4))
  else
      plot(rhsv1(:,3))
  end
    title('Lagged CR in region C')
  
    subplot(4,1,1)
  if gls==0 && ecm==1
      plot(rhsv1(:,5))
  else
      plot(rhsv1(:,4))
  end
  title('Lagged CR in region D')
  %%%%pause
   
   for j=1:rows(resultsa.beta)
       disp('ecm coefficients and t values')
       % JMM added the following line
       
      if gls==0 && ecm==1
        disp('dy(t) = constant, IAe(t-1), IBe(t-1), ICe(t-1), IDe(t-1),dx1(t-1), ?dx2(t-1)?, dy(t-1), ... dx1(t-pet2-1), dx2(t-pet2-1), dy(t-pet2-1)')
      else
        disp('dy(t) = IAe(t-1), IBe(t-1), ICe(t-1), IDe(t-1), dx1(t-1), ?dx2(t-1)?, dy(t-1), ... dx1(t-pet2-1), ?dx2(t-pet2-1)?, dy(t-pet2-1)')
      end
       %disp('dy(t) = constant IAe(t-1), IBe(t-1), dx(t-1), dy(t-1), ... dx(t-pet2-1), dy(t-pet2-1)')
 vertcat(resultsa.beta(j),resultsa.tstat(j))
 end  
 %%%%pause
     
 
disp('Optimal Delay Parameter')
jc

disp('best lag length in ecm is ')
pet2-1


%%%%pause

%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Estimate GARCH coefficients for ECM residuals 
%%% Take resultsa.resid and pass through the MFE toolbox GARCH procedure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if garch==1
garche=resultsa.resid;

% JMM modified lines 981 to 986
disp('Total Number of observations in ECM')
rows(garche)

disp('Mean of residuals from ECM')
mean(garche)

figure(771)
plot(garche)
title('Residuals from ECM')


garche1=garche-mean(garche);


[parameters, LL, ht, VCVrobust, VCV, scores, diagnostics] = tarch(garche1,1,0,1, 'NORMAL',2);
format long 
disp('garch parameters and robust t-stats')
garch22tstat=parameters./sqrt(diag(VCVrobust));
disp('constant')
vertcat(parameters(1,1),garch22tstat(1,1))
disp('arch')
vertcat(parameters(2,1),garch22tstat(2,1))
disp('garch')
vertcat(parameters(3,1),garch22tstat(3,1))
% August 19 - added next two lines. Remove if tarch(garche1,1,0,1, 'NORMAL',2)
%disp('gjh')
%vertcat(parameters(4,1),garch22tstat(4,1)) 
 

parameters
garch22tstat

else
end
 
 

%%%%%%%%start x ecm    
%%%%%%%% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%% Estimate ECM 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Reset indreg12w because in line 817 is built up with lags 
 % indpss = 1 if indicator <= threshold
 % run CR regression to get residuals
%sept 12 ehatw=yd-xd*(xd\yd);
ehatw=yd-xd*(xd\yd);
 % lag those residuals and use chosen jc 
 % gee
 
ehatlw=ehatw(1+pmax+jcmax-jc:rows(ehatw)-1-jc,1);
%december 2011
ehatvariable=ehatw(1+pmax+jcmax:rows(ehatw)-1,1);


eresids1=qindp1.*ehatvariable;
eresids2=qindp2.*ehatvariable;
eresids3=qindp3.*ehatvariable;
eresids4=qindp4.*ehatvariable;
% put lagged CR residuals together
rhsv=horzcat(eresids1,eresids2,eresids3,eresids4);

% create delta X and delta Y for ECM
newyd=yd(1+pmax+jcmax:rows(differe),1);
 dnewyd=yd(2+pmax+jcmax:rows(differe),1)-yd(1+pmax+jcmax:rows(differe)-1,1);;
 if cols(x)==1
 newxd=xd(1+pmax+jcmax:rows(differe),1);
 dnewxd=xd(2+pmax+jcmax:rows(differe),1)-xd(1+pmax+jcmax:rows(differe)-1,1);;
 else
      newxd=xd(1+pmax+jcmax:rows(differe),1:cols(x));
 dnewxd=xd(2+pmax+jcmax:rows(differe),1:cols(x))-xd(1+pmax+jcmax:rows(differe)-1,1:cols(x));;
 end
 
   
 yvar1=dnewyd(1+maxecmlag:rows(dnewyd),1);
 
 
 % open x column ecm loop
 
 for kl=1:cols(x)
     disp('ecm for this column of x')
     kl
     %%%%pause
 xvar1=dnewxd(1+maxecmlag:rows(dnewxd),kl);
 % no lags
 
  if gls==0 && ecm==1
 rhsv1=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:)) ;
 else
 rhsv1=rhsv(1+maxecmlag:rows(rhsv),:);
 end
 
 results=nwestpss(xvar1,rhsv1,round(rows(xvar1)^.25));
 
 % 
 disp('ecm estimates assuming no lagged changes in x and y, both set to be the same')
 
  if gls==0 && ecm==1
 xnew=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:));
  else
      xnew=rhsv(1+maxecmlag:rows(rhsv),:);
  end
 % no lags in ecm
 %results=ols(yvar1,indreg12wnew);
  
 bicnew(1)= (log((results.resid'*results.resid)/rows(results.resid)))+(log(rows(yvar1))*cols(rhsv1)/rows(yvar1));
 for j=1:rows(results.beta)
 vertcat(results.beta(j),results.tstat(j))
 end
 % lags 1 to maxecmlag
 for i=1:maxecmlag
   % August 3 - Changed to include all columns in X 
   xnew=[xnew dnewxd(1+maxecmlag-i:rows(dnewxd)-i,:),dnewyd(1+maxecmlag-i:rows(dnewyd)-i,1)];
   results=nwestpss(xvar1,xnew,round(rows(xvar1)^.25));
   
   
   bicnew(i+1)= (log((results.resid'*results.resid )/rows(results.resid)))+(log(rows(yvar1))*cols(xnew)/rows(yvar1)); 
 end
 [pet1,pet2]=min(bicnew);
 sort(bicnew)'
 disp('best lag length in ecm is ')
 pet2-1
 
if gls==0 && ecm==1
   xnewa=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:));
else
  xnewa=rhsv(1+maxecmlag:rows(rhsv),:);
end
  for i=1:pet2-1
      % August 3 - Changed to include all columns in X 
      xnewa=[xnewa dnewxd(1+maxecmlag-i:rows(dnewxd)-i,:),dnewyd(1+maxecmlag-i:rows(dnewyd)-i,1)];
    end
   resultsa=nwestpss(xvar1,xnewa,round(rows(xvar1)^.25));
   
  %JMM added plot 
  figure(5)
  subplot(4,1,4)
  if gls==0 && ecm==1
  plot(rhsv1(:,2))
  else
      plot(rhsv1(:,1))
  end
  title('Lagged CR in region A')
  
  subplot(4,1,3)
  if gls==0 && ecm==1
      plot(rhsv1(:,3))
  else
      plot(rhsv1(:,2))
  end
    title('Lagged CR in region B')
  
    subplot(4,1,2)
  if gls==0 && ecm==1
      plot(rhsv1(:,4))
  else
      plot(rhsv1(:,3))
  end
  title('Lagged CR in region C')
  
  subplot(4,1,1)
  if gls==0 && ecm==1
      plot(rhsv1(:,5))
  else
      plot(rhsv1(:,4))
  end
  title('Lagged CR in region D')
  %%%%pause
   
   for j=1:rows(resultsa.beta)
       disp('X ecm coefficients and t values')
       % JMM added the following line
       
       if gls==0 && ecm==1
        disp('dx(t) = constant, IAe(t-1), IBe(t-1), ICe(t-1), IDe(t-1), dx1(t-1), ?dx1(t-1)? ,dy(t-1), ... dx1(t-pet2-1), ?dx2(t-pet2-1)?, dy(t-pet2-1)')
      else
        disp('dx(t) = IAe(t-1), IBe(t-1), ICe(t-1), IDe(t-1), dx1(t-1), ?dx1(t-1)? , dy(t-1), ... dx1(t-pet2-1), ?dx2(t-pet2-1)?, dy(t-pet2-1)')
      end
       %disp('dx(t) = constant IAe(t-1), IBe(t-1), dx(t-1), dy(t-1), ... dx(t-pet2-1), dy(t-pet2-1)')
 vertcat(resultsa.beta(j),resultsa.tstat(j))
 end  
 %%%%pause
     
 
disp('Optimal Delay Parameter')
jc

disp('best lag length in ecm is ')
pet2-1

%%%%pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Estimate GARCH coefficients for ECM residuals 
%%% Take resultsa.resid and pass through the MFE toolbox GARCH procedure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if garch==1
garche=resultsa.resid;

% JMM modified lines 981 to 986
disp('Total Number of observations in ECM')
rows(garche)

disp('Mean of residuals from ECM')
mean(garche)

figure(771)
plot(garche)
title('Residuals from ECM')


garche1=garche-mean(garche);


[parameters, LL, ht, VCVrobust, VCV, scores, diagnostics] = tarch(garche1,1,0,1, 'NORMAL',2);
format long 
disp('garch parameters and robust t-stats')
garch22tstat=parameters./sqrt(diag(VCVrobust));
disp('constant')
vertcat(parameters(1,1),garch22tstat(1,1))
disp('arch')
vertcat(parameters(2,1),garch22tstat(2,1))
disp('garch')
vertcat(parameters(3,1),garch22tstat(3,1))
% August 19 - added next two lines. Remove if tarch(garche1,1,0,1, 'NORMAL',2)
%disp('gjh')
%vertcat(parameters(4,1),garch22tstat(4,1)) 
 
%%%%pause
parameters
garch22tstat
else
 end
% end loop over columns of x
 end

%%%%%%%%%%%%%%%%% end x ecm   
 
 format short

  
   
  
 
booters=resvar75;
     
   
 
 
boote=booters(2:rows(booters),1);
boottss=zeros(nboot,adflag3+4);
  
 

% here 
 
for jls=1:nboot
 
booters=resvar75q;
   
   
 
 
 
boote=booters(2:rows(booters),1);    
blocklen1=round(rows(boote)/blocklen);
     
   eboot1a=bootseo(boote,blocklen);
 
eboot=vertcat(booters(1,1),eboot1a);
 evar=cumsum(eboot);
  
   
     ebootl=evar(1:rows(eboot)-1,1);
  

 
    
    if rows(gfbetsas)>4
    for i=5:rows(gfbetsas)
       termq(i-4,1)=gfbetsas(i,1)*(evar(i-1,1)-evar(i-2,1));
    end
    end
dehatwboota1=evar(rows(gfbetsas)-2:rows(evar),1)-evar(rows(gfbetsas)-1-2:rows(evar)-1,1);
        
if rows(gfbetsas)>4
  dehatwboot=vertcat(termq,dehatwboota1);
end
       
if rows(gfbetsas)==4
  dehatwboot=evar(2:rows(evar),1)-evar(1:rows(evar)-1,1);
end


 
  
%   
%      
%      if seosearch==0
%      if margin==0
%       
%  n11=fix(perc*(rows(diffd1)));
% n12=fix((1-perc)*(rows(diffd1)));
% scrit=sort(diffd1);
% ed1=(scrit(n12-2*minobs,1)-scrit(n11,1))/ngrid;
% ed2=(scrit(n12-minobs,1)-scrit(n11+minobs,1))/ngrid;
% ed3=(scrit(n12,1)-scrit(n11+2*minobs,1))/ngrid;
% 
%     thresholdsa=(scrit(n11,1):ed1:scrit(n12-2*minobs,1))';
%     thresholdse=(scrit(n11+minobs,1):ed2:scrit(n12-minobs,1))';
%     thresholdsb=(scrit(n11+(2*minobs),1):ed3:scrit(n12,1))';
%     
%    else
%   n11=fix(perc*(rows(ebootl)));
% n12=fix((1-perc)*(rows(ebootl)));
% scrit=sort(ebootl);
%  
% ed1=(scrit(n12-2*minobs,1)-scrit(n11,1))/ngrid;
% ed2=(scrit(n12-minobs,1)-scrit(n11+minobs,1))/ngrid;
% ed3=(scrit(n12,1)-scrit(n11+2*minobs,1))/ngrid;
% 
%     thresholdsa=(scrit(n11,1):ed1:scrit(n12-2*minobs,1))';
%     thresholdse=(scrit(n11+minobs,1):ed2:scrit(n12-minobs,1))';
%     thresholdsb=(scrit(n11+(2*minobs),1):ed3:scrit(n12,1))';
%                   
%    end
% %    if margin==0
% % n11=round(1.0*perc*(rows(diffd1)));
% % n12=round((1.0-perc)*(rows(diffd1)));
% % sdiffd=sort(diffd1);
% % ed=(sdiffd(n12,1)-sdiffd(n11,1))/ngrid;
% %     thresholdsa=(sdiffd(n11,1):ed:sdiffd(n12-2*minobs,1))';
% %     thresholdse= (sdiffd(n11+minobs,1):ed:sdiffd(n12-minobs,1))';
% %     thresholdsb= (sdiffd(n11+2*minobs,1):ed:sdiffd(n12,1))';
% %    end
% %    if margin==1
% %     sus=sort(ebootl);
% % n1=round(1.0*perc*rows(ebootl));
% % n2=round((1.0-perc)*rows(ebootl));
% % ed=(sus(n2,1)-sus(n1,1))/ngrid;
% % thresholdsa=(sus(n1,1):ed:sus(n2-2*minobs,1))'    ;
% % thresholdse=(sus(n1+minobs,1):ed:sus(n2-minobs,1))'    ;
% % thresholdsb=(sus(n1+2*minobs,1):ed:sus(n2,1))'    ;
% % 
% %    
% %    end
% 
%      end
     
%      
%       if seosearch==1
%            
%   %fix at actual search values, thresoldvar1 based on diffd1 or ehatlw and
%   %returned from realseoone
%     thresholdse=thresh3e;
%     thresholdsa=thresh3a;
%     thresholdsb=thresh3b;
  %threshs=horzcat(thresh3a,thresh3e,thresh3b);
   
%       end
     
     
     
    
[fftestboots(jls,1),boottss(jls,1:4+adflag3)]=threeboot(jc,evar,differe(1:rows(evar),1),perc,margin,jcmax,adflag3,minobs,ngrid,seosearch,thresh3a,thresh3e,thresh3b);

% [fftestboots(jls,1),boottss(jls,1:4+adflag3)]=threeboot(jc,evar,differe(1:rows(evar),1),perc,margin,jcmax,adflag3,minobs,ngrid,seosearch,thresholdse,thresholdsa,thresholdsb,maxip);

 

% 
% 
% 
% counterb=0;
% for lljs=1:rows(thresholdsa);
%      
%       % begn search for threshold
%      seconda=thresholdsa(lljs,1);
% for jwls=1:rows(thresholdse);
%    firstt=thresholdse(jwls,1);
%     for jjls=1:rows(thresholdsb)
%         secondb=thresholdsb(jjls,1);
%  
%      counterb=counterb+1;
%  
%  if margin==0
%             
% for i=1:1:rows(eboot)-1
%  if diffd1(i,1)<=seconda
%         sraegre1(i,1)=ebootl(i,1);
%     else
%         sraegre1(i,1)=0;
%  end
%     if seconda<diffd1(i,1) && diffd1(i,1)<=firstt
%         sraegre2(i,1)=ebootl(i,1);
%     else
%         sraegre2(i,1)=0;
%     end
%     if firstt<diffd1(i,1) && diffd1(i,1)<=secondb
%         sraegre3(i,1)=ebootl(i,1);
%     else
%         sraegre3(i,1)=0;
%     end
%     if diffd1(i,1)>secondb
%         sraegre4(i,1)=ebootl(i,1);
%     else
%         sraegre4(i,1)=0;
%     end
% end
%  end  
%      
%  
% firstc=bestjclag;
%  
%             if margin==1
% for i=1+firstc:1:rows(eboot)-1
%      if ebootl(i-firstc,1)<=seconda
%         sraegre1(i,1)=ebootl(i,1);
%     else
%         sraegre1(i,1)=0;
%      end
%     if seconda<ebootl(i-firstc,1) && ebootl(i-firstc,1)<=firstt
%         sraegre2(i,1)=ebootl(i,1);
%     else
%         sraegre2(i,1)=0;
%     end
%     if firstt<ebootl(i-firstc,1) && ebootl(i-firstc,1)<=secondb
%         sraegre3(i,1)=ebootl(i,1);
%     else
%         sraegre3(i,1)=0;
%     end
%     if ebootl(i-firstc,1)>secondb
%         sraegre4(i,1)=ebootl(i,1);
%     else
%         sraegre4(i,1)=0;
%     end
% end
%             end
%             
%               j1=sraegre1(sraegre1~=0); rj1=rows(j1);
%     j2=sraegre2(sraegre2~=0);rj2=rows(j2);
%     j3=sraegre3(sraegre3~=0);rj3=rows(j3);
%     j4=sraegre4(sraegre4~=0);rj4=rows(j4);
%    rj1;
%    rj2;
%    rj3;
%    rj4;
%   
%    
%    
%    if rj1>=minobs & rj2>=minobs & rj3>=minobs & rj4>=minobs
%     
%             
%     
% cpeterabce=horzcat(sraegre1,sraegre2,sraegre3,sraegre4);
%      
%  
%    
% vsindreg12wa=cpeterabce;
%    dehatbr1=dehatwboot;
%      boottss99(counterb,1:adflag3+4)=zeros(1,1:adflag3+4);
% 
%      bestbetas99(counterb,1:adflag3+4)=zeros(1,1:adflag3+4);
%       
%       
%  
%      
%  
% 
%    [fftestbootss(jls,1),betaboots5,tsboot5,seosignew,revarn]=ftessadfb(dehatbr1,vsindreg12wa,adflag3);  
% g1=cols(tsboot5);
%    boottss99(counterb,:)=horzcat(tsboot5(1,:),zeros(1:adflag3+4-g1));
%       if adflag3>0
%       [topsignew]=ftessjan(dehatbr1,adflag3); 
%    else
%        topsignew=(dehatbr1'*dehatbr1)/rows(dehatbr1);
%    end
% 
%      fftestboots99(counterb,1)=rows(revarn)*((topsignew/seosignew)-1);
%  
%  
%  
% 
%  else
%        fftestboots99(counterb,1)=0;
%    boottss99(counterb,1:adflag3+4)=zeros(1,adflag3+4);
%  
%      bestbetas99(counterb,1:adflag3+4)=zeros(1,adflag3+4);
%  
%    end
%  
%  
%  
%   end
%   
% end
%   
%   
% end
% 
 %[h11s,h22s]=max(fftestboots99);
%  
   %fftestboots(jls,1)=fftestboots99(h22s,1);
%    
   %boottss(jls,:)=boottss99(h22s,:);
%  
%   
end

boottss = boottss(any(boottss,2),:) ;
fftestboots(fftestboots==0)=[];

 
% fftestboots
% boottss = boottss(any(boottss,2),:) ;
% fftestboots=fftestboots(any(fftestboots,2),:);

% %%%%pause
 nboot1=rows(boottss);
 nboot2=rows(fftestboots);
 %rows(fftestboots)
% %%%%pause
 

boottssa=sort(boottss);
bootcvt=boottssa(round(0.05*nboot1),:);
disp('bootstrap 5% lower tail critical values for t tests')
bootcvt
 

%new sept 21
bootcvt1=bootcvt;
boottss1=boottssa;
% see if t tests on lagged ADF terms are symmetric
if cols(bootcvt1)>4
    disp('cols bootcvt1')
    cols(bootcvt1)
  
bootnew=boottss1(round(0.95*nboot1),5:cols(bootcvt1));
disp('t values on lagged ADF terms in bootstrapping test equation')
disp('lower 5% and upper 95% values, should be similar but different sign')
cols(bootnew)
horzcat(bootcvt1(5:cols(bootcvt1)),bootnew)
 figure(9039)
 plot(boottss1(round(0.95*nboot1):rows(boottss1),5:cols(bootcvt1)));
 
for i=5:cols(bootcvt1)
    %compare to actual t's in testing equation
    if gfts(i,1)<0
boottvalnew(:,i-4)=(boottss1(:,i))<(gfts(i,1)); 
    end
    if gfts(i,1)>=0
boottvalnew(:,i-4)=(boottss1(:,i))>=(gfts(i,1)); 
    end
end
 
for i=5:cols(bootcvt1)
bootps1new(:,i-4)=(cumsum(boottvalnew(:,i-4)))/rows(boottss1);
tpvaluenew(1,i-4)=bootps1new(rows(bootps1new),i-4);
end
disp('pvalues of t stats on ADF coefficients in testing equation')
 
  tpvaluenew

 

end

% end new Sept 21



disp('peter here')
cols(bootcvt)
for i=1:cols(bootcvt)
    %compare to actual t's in testing equation
boottval(:,i)=boottss(:,i)<gfts(i,1); 
end
 
for i=1:cols(bootcvt)
bootps1(:,i)=(cumsum(boottval(:,i)))/rows(boottssa);
tpvalue(1,i)=bootps1(rows(bootps1),i);
end
disp('pvalues of t stats in testing equation')

disp('four in this case are for the four indicator variables given there are three thresholds here')
%sept 21 write out first 4 and then others from above for ADF terms
if cols(bootcvt1)>4
horzcat(tpvalue(1,1:4),tpvaluenew)
end
if cols(bootcvt1)==4
    tpvalue
end

disp('correct?')


% Janelle 20190708 Commented out Figure 
% figure(89021)
% plot(boottssa)
ed=(1:1:rows(boottssa))';
% figure(890312)
% plot(ed,boottssa)
% figure(8930222)
% plot(boottssa,ed)
bootffs=sort(fftestboots);

disp(' bootstrap 5% F value')
bootv=bootffs(round(.95*nboot2),1);
disp('test value and bootstrap 5%')

horzcat(newtestval,bootv)
bootp1=bootffs>newtestval;bootpvalue1=cumsum(bootp1)/rows(bootffs);
bootpvalue=bootpvalue1(rows(bootpvalue1),1);
disp('test value and bootstrap 5% critical value and pvalue')
horzcat(newtestval,bootv,bootpvalue)
disp('optimal lag length for indicator variable')
if margin==0
disp('price difference at lag')
firstc
else
  disp('cointegration residual at lag')
firstc;  
end

 set(0,'defaultaxescolororder',[0,0,0],...
     'defaultaxeslinestyleorder','-|--|:|-.')
figure(1)
prob=((1/nboot2):(1/nboot2):1);

plot(bootffs',prob,'-bl')
ylabel('Cumulative Probability')
xlabel('Test Statistic')
title('Figure X: Cumulative Density of Bootstrap Test Statistic')
% 202210 h=legend('Test Statistic',1);
% 202210 set(h,'Interpreter','none')
 
figure(2)
[h1 f1a y1]=pltdens(bootffs);
 plot(y1,f1a,'-.r');
 ylabel('Probability')
xlabel('Test Statistic')

title('Figure X: Empirical Bootstrap Distribution of Test Statistic')
% 202210 h=legend('Test Statistic',1);
% 202210 set(h,'Interpreter','none')

figure(100)
x=bootffs;
 p.lB=0;
p.uB=inf;
p.alpha=0.95;
%fhandle=figure; 
gkdeb(bootffs,p);
axis([ -1 10 0 1.5]);
p=gkdeb(bootffs);
axis([ -1 10 0 1.3]);

    

end
% above ends 3 threshold case
toc
% ^^^^^^^^^^^^^ one threshold below
if numtau==2
disp('single threshold found')
 

threshold1 = firstt
 
% 
 
% check to ensure at least minobs in each subregion
jc=bestjclag;
firstc=jc;
diffd1=differe(1+pmax+jcmax-jc:rows(differe)-1-jc,1);
ehatvar=ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
 ehatlw=ehatw(1+pmax+jcmax-jc:rows(ehatw)-1-jc,1);
 dehatw1=ehatw(2+pmax+jcmax:rows(ehatw),1)-ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
 
%  
%      
   if margin==0
n11=round(1.0*perc*(rows(diffd1)));
n12=round((1.0-perc)*(rows(diffd1)));
sdiffd=sort(diffd1);
ed=(sdiffd(n12,1)-sdiffd(n11,1))/ngrid;
    thresh11=(sdiffd(n11,1):ed:sdiffd(n12,1))';
   end
   if margin==1
    sus=sort(ehatlw);
n1=round(1.0*perc*rows(ehatlw));
n2=round((1.0-perc)*rows(ehatlw));
ed=(sus(n2,1)-sus(n1,1))/ngrid;
thresh11=(sus(n1,1):ed:sus(n2,1))'    ;
   end

 
 

disp('Seo F test ')
bestf1;
newtestval=bestf1;

% if margin==0
%     for i=1:rows(diffd1)
% if diffd1(i,1)<=firstt   
%   indpss(i,1)=1;
% else
%     indpss(i,1)=0;
% end
%     end
%  
% else
%  for i=1:rows(ehatlw)
% if ehatlw(i,1)<=firstt   
%   indpss(i,1)=1;
% else
%     indpss(i,1)=0;
% end
%  end
% end
  if margin==0
           
    % for i=1:1:rows(diffd1)
 indpss=(diffd1<=firstt);
           zindreg1w=(diffd1<=firstt).*ehatvar;
          zindreg2w=(diffd1>firstt).*ehatvar;
             
 
 end
     
  
            if margin==1
indpss=(ehatlw<=firstt);
           zindreg1w=(ehatlw<=firstt).*ehatvar;
           zindreg2w=(ehatlw>firstt).*ehatvar;
         
            end 
% zindreg1w=indpss.*ehatvar;
% zindreg2w=(1-indpss).*ehatvar;
mindreg12w=horzcat(zindreg1w,zindreg2w);
 

xindreg12w=horzcat(zindreg1w,zindreg2w);
 
  
  numbelow1=zindreg1w;
            numbelow1(numbelow1==0)=[];
           smplbelow1=rows(numbelow1);
            
            numbelow2=zindreg2w;
            numbelow2(numbelow2==0)=[];
           smplbelow2=rows(numbelow2);
  
    disp('observations within each region')
           disp('below lowest threshold')
           smplbelow1
        disp('above the highest  threshold')
           smplbelow2
   disp('total sample is ')
           rows(dehatw1)
           disp('sum of subregions is')
           smplbelow1+smplbelow2 
           
           %%%%pause
           
   if adflag1==0
     resvarx=dehatw1-mindreg12w*(mindreg12w\dehatw1);

 end
 if adflag1>0    
    X1=mindreg12w;
    for ir=1:1:adflag1
        X1 = [X1 ehatw(2+pmax+jcmax-ir:rows(ehatw)-ir,1)-ehatw(1+pmax+jcmax-ir:rows(ehatw)-1-ir,1)];
    end
        y=dehatw1;
   resvarx=y-X1*(X1\y);

 end
  
  
  tj2=adflag1;
  disp('one threshold')
  betas=bestbetas1';
  betas(betas==0)=[];
  ts=bestt1';
  ts(ts==0)=[];
  
  
  
  
  
disp('f test for coefficients on lagged residuals above and below threshold jointly zero')
newtestval
 disp('coefficients and their t tests for null of zero')
 disp('first coeff, below the first threshold')
 vertcat(betas(1,1),ts(1,1))
 disp('second coeff, above the first threshold')
 vertcat(betas(2,1),ts(2,1))
  
  
 
 
 wfred=rows(betas);
 
 
     disp('lag length in ADF test version')
 adflag1
 % write out ADF lagged dependent variable version if newey=2
 if wfred>2
 
     for i=3:rows(betas)
 
disp('ADF coefficient and t')
 vertcat(betas(i,1),ts(i,1))
 end
 end
 
 % graph results
 tau1=firstt.*ones(rows(ehatw),1); 
 
 
 figure(901433)
 hold on
 plot(tau1,'-b')
 %march 12/12
 if margin==0
 plot(ehatvar,'-g')
 end
 if margin==1
     plot(ehatvar,'-g')
 end
 %march 12/12
 % old replaced above march 12/12  plot(ehatw,'-g')
 hold off
 
 
 
 
 
 
 
 %%%%%% start new ecm
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%% Estimate ECM 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Reset indreg12w because in line 817 is built up with lags 
 % indpss = 1 if indicator <= threshold
 % run CR regression to get residuals
 %sept 12 ehatw=yd-xd*(xd\yd);
ehatw=yd-xd*(xd\yd);
 % lag those residuals and use chosen jc 
 %gee
 
ehatlw=ehatw(1+pmax+jcmax-jc:rows(ehatw)-1-jc,1);
 

ehatvariable=ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
 


resids1=indpss.*ehatvariable;
resids2=(1.0-indpss).*ehatvariable;
eddie=horzcat(indpss,1.0-indpss);

% put lagged CR residuals together
rhsv=horzcat(resids1,resids2);
% create delta X and delta Y for ECM
newyd=yd(2+pmax+jcmax:rows(differe),1);
 dnewyd=yd(2+pmax+jcmax:rows(differe),1)-yd(1+pmax+jcmax:rows(differe)-1,1);;
 % note only picks out first column of x
 % if x contains more than 1 vbl then need to adjust code below
 %
 if cols(x)==1
 % orig below
 newxd=xd(1+pmax+jcmax:rows(differe),1);
 dnewxd=xd(2+pmax+jcmax:rows(differe),1)-xd(1+pmax+jcmax:rows(differe)-1,1);;
% original above
 else
 newxd=xd(1+pmax+jcmax:rows(differe),1:cols(x));
 dnewxd=xd(2+pmax+jcmax:rows(differe),1:cols(x))-xd(1+pmax+jcmax:rows(differe)-1,1:cols(x));;
 end
     
 yvar1=dnewyd(1+maxecmlag:rows(dnewyd),1);
 xvar1=dnewxd(1+maxecmlag:rows(dnewxd),1);
 % no lags
 
 if gls==0 && ecm==1
 rhsv1=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:)) ;
 else
 rhsv1=rhsv(1+maxecmlag:rows(rhsv),:);
 end
 
 results=nwestpss(yvar1,rhsv1,round(rows(yvar1)^.25));
 % disp('here july 25')
 %%%%pause
  
 % 
 disp('ecm estimates assuming maxecmlag lagged changes in x and y, both set to be the same')
  
 
  if gls==0 && ecm==1
 xnew=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:));
  else
      xnew=rhsv(1+maxecmlag:rows(rhsv),:);
  end
 % no lags in ecm
 %results=ols(yvar1,indreg12wnew);
  
 bicnew(1)= (log((results.resid'*results.resid)/rows(yvar1)))+(log(rows(yvar1))*cols(rhsv1)/rows(yvar1));
 for j=1:rows(results.beta)
 vertcat(results.beta(j),results.tstat(j))
 end
 % lags 1 to maxecmlag
 for i=1:maxecmlag
    xnew=[xnew dnewxd(1+maxecmlag-i:rows(dnewxd)-i,:),dnewyd(1+maxecmlag-i:rows(dnewyd)-i,1)];
   results=nwestpss(yvar1,xnew,round(rows(yvar1)^.25));
    
%  
  %%%%pause  
%    
   bicnew(i+1)= (log((results.resid'*results.resid)/rows(yvar1)))+(log(rows(yvar1))*cols(xnew)/rows(yvar1)); 
 end
 [pet1,pet2]=min(bicnew);
 sort(bicnew)'
 disp('best lag length in ecm is ')
 pet2-1
 
if gls==0 && ecm==1
 
  xnewa=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:));
else
  xnewa=rhsv(1+maxecmlag:rows(rhsv),:);
end
  for i=1:pet2-1
        xnewa=[xnewa dnewxd(1+maxecmlag-i:rows(dnewxd)-i,:),dnewyd(1+maxecmlag-i:rows(dnewyd)-i,1)];
    end
   resultsa=nwestpss(yvar1,xnewa,round(rows(yvar1)^.25));
   
  %JMM added plot 
  figure(1)
  subplot(2,1,2)
  if gls==0 && ecm==1
  plot(rhsv1(:,2))
  else
      plot(rhsv1(:,1))
  end
  title('Lagged CR in region A')
 
  subplot(2,1,1)
  if gls==0 && ecm==1
      plot(rhsv1(:,3))
  else
      plot(rhsv1(:,2))
  end
  title('Lagged CR in region B')
  
  %%%%pause
   
   for j=1:rows(resultsa.beta)
       disp('ecm coefficients and t values')
       % JMM added the following line
       % August 3 - Modified if statment to account for more than one
       % lagged x in the ECM
        if gls==0 && ecm==1
        disp('dy(t) = constant, IAe(t-1), IBe(t-1), dx1(t-1), ?dx2(t-1)?, dy(t-1), ... dx1(t-pet2-1), ?dx2(t-pet2-1)? + dy(t-pet2-1)')
      else
        disp('dy(t) = IAe(t-1), IBe(t-1), dx1(t-1), ?dx2(t-1)?,dy(t-1), ... dx1(t-pet2-1),?dx2(t-pet2-1)?, dy(t-pet2-1)')
      end
 vertcat(resultsa.beta(j),resultsa.tstat(j))
 end  
 %%%%pause
    
 
disp('Optimal Delay Parameter')
jc

disp('best lag length in ecm is ')
pet2-1

% disp('idiot Peter')
%%%%pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Estimate GARCH coefficients for ECM residuals 
%%% Take resultsa.resid and pass through the MFE toolbox GARCH procedure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if garch==1
garche=resultsa.resid;

% JMM modified lines 981 to 986
disp('Total Number of observations in ECM')
rows(garche)

disp('Mean of residuals from ECM')
mean(garche)

figure(771)
plot(garche)
title('Residuals from ECM')

garche1=garche-mean(garche);

[parameters, LL, ht, VCVrobust, VCV, scores, diagnostics] = tarch(garche1,1,0,1, 'NORMAL',2);
format long 
disp('garch parameters and robust t-stats')
garch22tstat=parameters./sqrt(diag(VCVrobust));
disp('constant')
vertcat(parameters(1,1),garch22tstat(1,1))
disp('arch')
vertcat(parameters(2,1),garch22tstat(2,1))
disp('garch')
vertcat(parameters(3,1),garch22tstat(3,1))
% August 19 - added next two lines. Remove if tarch(garche1,1,0,1, 'NORMAL',2)
%disp('gjh')
%vertcat(parameters(4,1),garch22tstat(4,1)) 

%%%%pause
parameters
garch22tstat

%%%%pause
format short
%%%%pause
else
end
%%%%%%%%start x ecm    
%%%%%%%% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%% Estimate ECM 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Reset indreg12w because in line 817 is built up with lags 
 % indpss = 1 if indicator <= threshold
 % run CR regression to get residuals
 %sept 12 ehatw=yd-xd*(xd\yd);
ehatw=yd-xd*(xd\yd);
 % lag those residuals and use chosen jc 
 %gee
 
ehatlw=ehatw(1+pmax+jcmax-jc:rows(ehatw)-1-jc,1);

ehatvariable=ehatw(1+pmax+jcmax:rows(ehatw)-1,1);


resids1=indpss.*ehatvariable;
resids2=(1.0-indpss).*ehatvariable;
eddie=horzcat(indpss,1.0-indpss);
%August 3

% put lagged CR residuals together
rhsv=horzcat(resids1,resids2);
% create delta X and delta Y for ECM
newyd=yd(1+pmax+jcmax:rows(differe),1);
 dnewyd=yd(2+pmax+jcmax:rows(differe),1)-yd(1+pmax+jcmax:rows(differe)-1,1);;
 if cols(x)==1
 newxd=xd(1+pmax+jcmax:rows(differe),1);
 dnewxd=xd(2+pmax+jcmax:rows(differe),1)-xd(1+pmax+jcmax:rows(differe)-1,1);;
 else
      newxd=xd(1+pmax+jcmax:rows(differe),1:cols(x));
 dnewxd=xd(2+pmax+jcmax:rows(differe),1:cols(x))-xd(1+pmax+jcmax:rows(differe)-1,1:cols(x));;
 end
 
   
 yvar1=dnewyd(1+maxecmlag:rows(dnewyd),1);
 
 
 
 % open x column ecm loop
 
 for kl=1:cols(x)
     disp('ecm for this column of x')
     kl
 xvar1=dnewxd(1+maxecmlag:rows(dnewxd),kl);
 % no lags
 
 
 if gls==0 && ecm==1
 rhsv1=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:)) ;
 else
 rhsv1=rhsv(1+maxecmlag:rows(rhsv),:);
 end
 
 results=nwestpss(xvar1,rhsv1,round(rows(xvar1)^.25));
 % disp('here july 25')
 %%%%pause
 
 % 
 disp('ecm estimates assuming maxecmlag lagged changes in x and y, both set to be the same')

 
  if gls==0 && ecm==1
 xnew=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:));
  else
      xnew=rhsv(1+maxecmlag:rows(rhsv),:);
  end
 % no lags in ecm
 %results=ols(yvar1,indreg12wnew);
  
 bicnew(1)= (log((results.resid'*results.resid)/rows(yvar1)))+(log(rows(yvar1))*cols(rhsv1)/rows(yvar1));
 for j=1:rows(results.beta)
 vertcat(results.beta(j),results.tstat(j))
 end
 % lags 1 to maxecmlag
 for i=1:maxecmlag
   % August 3 - Changed to include all columns in X 
   xnew=[xnew dnewxd(1+maxecmlag-i:rows(dnewxd)-i,:),dnewyd(1+maxecmlag-i:rows(dnewyd)-i,1)];
   results=nwestpss(xvar1,xnew,round(rows(xvar1)^.25));
   
   
   bicnew(i+1)= (log((results.resid'*results.resid)/rows(yvar1)))+(log(rows(yvar1))*cols(xnew)/rows(yvar1)); 
 end
 [pet1,pet2]=min(bicnew);
 sort(bicnew)'
 disp('best lag length in ecm is ')
 pet2-1
 
if gls==0 && ecm==1
 
  xnewa=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:));
else
  xnewa=rhsv(1+maxecmlag:rows(rhsv),:);
end
  for i=1:pet2-1
      % August 3 - Changed to include all columns in X
        xnewa=[xnewa dnewxd(1+maxecmlag-i:rows(dnewxd)-i,:),dnewyd(1+maxecmlag-i:rows(dnewyd)-i,1)];
    end
   resultsa=nwestpss(xvar1,xnewa,round(rows(xvar1)^.25));
   
  %JMM added plot 
  figure(1)
  subplot(2,1,2)
  if gls==0 && ecm==1
  plot(rhsv1(:,2))
  else
      plot(rhsv1(:,1))
  end
  title('Lagged CR in region A')
  
  subplot(2,1,1)
  if gls==0 && ecm==1
      plot(rhsv1(:,3))
  else
      plot(rhsv1(:,2))
  end
  title('Lagged CR in region B')
  
  %%%%pause
   
   for j=1:rows(resultsa.beta)
       disp('X ecm coefficients and t values')
       % JMM added the following line
       
       % August 3 - Modified if statment to account for more than one
       % lagged x in the ECM
      if gls==0 && ecm==1
        disp('dy(t) = constant, IAe(t-1), IBe(t-1), dx1(t-1), ?dx2(t-1)?, dy(t-1), ... dx1(t-pet2-1), ?dx2(t-pet2-1)? + dy(t-pet2-1)')
      else
        disp('dy(t) = IAe(t-1), IBe(t-1), dx1(t-1), ?dx2(t-1)?,dy(t-1), ... dx(t-pet2-1), ?dx2(t-pet2-1)?, dy(t-pet2-1)')
      end
       %disp('dx(t) = constant IAe(t-1), IBe(t-1), dx(t-1), dy(t-1), ... dx(t-pet2-1), dy(t-pet2-1)')
 vertcat(resultsa.beta(j),resultsa.tstat(j))
 end  
 %%%%pause
     
 
disp('Optimal Delay Parameter')
jc

disp('best lag length in ecm is ')
pet2-1

% disp('idiot Peter')
%%%%pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Estimate GARCH coefficients for ECM residuals 
%%% Take resultsa.resid and pass through the MFE toolbox GARCH procedure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if garch==1
garche=resultsa.resid;

% JMM modified lines 981 to 986
disp('Total Number of observations in ECM')
rows(garche)

disp('Mean of residuals from ECM')
mean(garche)

figure(771)
plot(garche)
title('Residuals from ECM')

garche1=garche-mean(garche);

[parameters, LL, ht, VCVrobust, VCV, scores, diagnostics] = tarch(garche1,1,0,1, 'NORMAL',2);
format long 
disp('garch parameters and robust t-stats')
garch22tstat=parameters./sqrt(diag(VCVrobust));
disp('constant')
vertcat(parameters(1,1),garch22tstat(1,1))
disp('arch')
vertcat(parameters(2,1),garch22tstat(2,1))
disp('garch')
vertcat(parameters(3,1),garch22tstat(3,1))
% August 19 - added next two lines. Remove if tarch(garche1,1,0,1, 'NORMAL',2)
%disp('gjh')
%vertcat(parameters(4,1),garch22tstat(4,1)) 

%%%%pause
parameters
garch22tstat
else
 end

% end loop over columns of x
 end

%%%%%%%%%%%%%%%%% end x ecm   
 
 
 
 
    
 
 
 format short
 
 

 %%%%%%%%%%% boot below
% block bootstrap following Seo (2008)
 
booter=resvarx;
%booter=dehatw1-xindreg12w*betas(1:2,1); 
 

boote=booter(2:rows(booter),1);
 
for jlss=1:nboot
     %  eboot=sample(boote,rows(dehatw),1); April 26
     blocklen1=round(rows(boote)/blocklen);
   eboot1=bootseo(boote,blocklen);
    
   
   
   
% is Y1 booter(1,1)
 
eboot=vertcat(booter(1,1),eboot1);
 
 
evar=cumsum(eboot);


 
    if rows(betas)>2
    for i=3:rows(betas)
       term(i-2,1)=betas(i,1)*(evar(i-1,1)-evar(i-2,1));
    end
    end
     
dehatwboota=evar(rows(betas):rows(evar),1)-evar(rows(betas)-1:rows(evar)-1,1);
 

   % eboot=sample(boote,rows(dehatw),1);
   
  
 
if rows(betas)>2       
  dehatwboot=vertcat(term,dehatwboota);
end
if rows(betas)==2       
  dehatwboot=evar(2:rows(evar),1)-evar(1:rows(evar)-1,1);
end



  

 
  
    dehatb1=dehatwboot;
     
     ebootl=evar(1:rows(eboot)-1,1);
% 
 [fftestboots(jlss,1),boott1s(jlss,1:adflag1+2)]=oneboot(jc,evar,differe(1:rows(evar)),perc,margin,jcmax,adflag1,minobs,ngrid,seosearch,thresh11);



%         if seosearch==0
%        if margin==0
% n11=round(1.0*perc*(rows(diffd1)));
% n12=round((1.0-perc)*(rows(diffd1)));
% sdiffd=sort(diffd1);
% ed=(sdiffd(n12,1)-sdiffd(n11,1))/ngrid;
%     thresholdse=(sdiffd(n11,1):ed:sdiffd(n12,1))';
%    end
%    if margin==1
%     sus=sort(ebootl);
% n1=round(1.0*perc*rows(ebootl));
% n2=round((1.0-perc)*rows(ebootl));
% ed=(sus(n2,1)-sus(n1,1))/ngrid;
% thresholdse=(sus(n1,1):ed:sus(n2,1))'    ;
%    end
%         end
%           if seosearch==1
%          thresholdse=thresh11;
%           end
            
     
%    
%    counterb=0;
%    for jls=1:rows(thresholdse);
%       % begn search for threshold
%      firstt9=thresholdse(jls,1);
%      counterb=counterb+1;
%    if margin==0
% for i=1:rows(eboot)-1
% if diffd1(i,1)<=firstt9  
%   indvpssa(i,1)=1;
% else
%     indvpssa(i,1)=0;
% end
% end
% else
% for i=1+firstc:rows(eboot)-1
% if ebootl(i-firstc,1)<=firstt9   
%   indvpssa(i,1)=1;
% else
%     indvpssa(i,1)=0;
% end
% end
%    end
%  
%    
%    
% indreg1fw=indvpssa.*ebootl;
% indreg2fw=(1-indvpssa).*ebootl;
% indreg1f2wa=horzcat(indreg1fw,indreg2fw);
% lindreg1f2wa=horzcat(indreg1fw,indreg2fw);
%    dehatb1=dehatwboot;
%                j1=indreg1fw(indreg1fw~=0); rj1=rows(j1);
%     j2=indreg2fw(indreg2fw~=0);rj2=rows(j2);
%    
%    rj1;
%    rj2;
%    
%   
%    
%    
%    if rj1>=minobs & rj2>=minobs  
%     
%    
%    boottss99(counterb,1:adflag1+2)=zeros(1,1:adflag1+2);
% 
%      bestbetas99(counterb,1:adflag1+2)=zeros(1,1:adflag1+2);
%       
%  
%   
%    
%   [fftestbootts(jls,1),betaboots1,tsboot111,seosignew,rewvar]=ftessadfoneb(dehatb1,indreg1f2wa,adflag1);  
% g1=cols(tsboot111);
%    boottss99(counterb,:)=horzcat(tsboot111(1,:),zeros(1:adflag1+2-g1));
%    
%       if tj2>0
%     [topsignew]=ftessjan(dehatb1,adflag1); 
%    else
%        topsignew=(dehatb1'*dehatb1)/rows(dehatb1);
%       end
%     fftestboots99(counterb,1)=rows(rewvar)*((topsignew/seosignew)-1);
%  
%  
%     else
%        fftestboots(jlss,1)=0;
%    boott1s(jlss,1:adflag1+2)=zeros(1,adflag1+2);
%  
    
 
   end
   
 
 



 
%   find biggest F for this bootstrap sample
%    [ju1,ju2]=max(fftestboots99);
%    fftestboots(jlss,1)=fftestboots99(ju2,1);
%    boott1s(jlss,:)=boottss99(ju2,:);     


 boottss = boott1s(any(boott1s,2),:) ;
fftestboots(fftestboots==0)=[];

nboot1=rows(boottss);
nboot2=rows(fftestboots);
bootffs=sort(fftestboots);
boottss1=sort(boottss);
figure(8900)
plot(boottss1)
% 5% lower tail critical value for t tests
bootcvt1=boottss1(round(0.05*nboot1),:);
 disp('bootstrap 5% lower tail critical values for t tests')
bootcvt1
%%%%pause
 
%new sept 21
% see if t tests on lagged ADF terms are symmetric
if cols(bootcvt1)>2
    disp('cols bootcvt1')
    cols(bootcvt1)
    %%%%pause
    %boottss1=boottssa;
bootnew=boottss1(round(0.95*nboot1),3:cols(bootcvt1));
disp('t values on lagged ADF terms in bootstrapping test equation')
disp('lower 5% and upper 95% values, should be similar but different sign')
cols(bootnew)
horzcat(bootcvt1(3:cols(bootcvt1)),bootnew)
 
for i=3:cols(bootcvt1)
    %compare to actual t's in testing equation
    if ts(i,1)<0
boottvalnew(:,i-2)=(boottss1(:,i))<(ts(i,1)); 
    end
    if ts(i,1)>=0
boottvalnew(:,i-2)=(boottss1(:,i))>=(ts(i,1)); 
    end
end
 
for i=3:cols(bootcvt1)
bootps1new(:,i-2)=(cumsum(boottvalnew(:,i-2)))/rows(boottss1);
tpvaluenew(1,i-2)=bootps1new(rows(bootps1new),i-2);
end
disp('pvalues of t stats on ADF coefficients in testing equation')
 
  tpvaluenew
  %%%%pause
 

end

% end new Sept 21




% figure (1)
% figure(3) 
% plot(bootffs);
 
 
 % August 3 - Added lines 
 %%%%%%%%%p-values for t-tests%%%%%%%%%%%%%%%

% disp('peter here')
cols(bootcvt1)
for i=1:cols(bootcvt1)
    %compare to actual t's in testing equation
boottval(:,i)=boottss1(:,i)<ts(i,1); 
end
  
for i=1:cols(bootcvt1)
bootps1(:,i)=(cumsum(boottval(:,i)))/rows(boottss1);
tpvalue(1,i)=bootps1(rows(bootps1),i)
end
disp('pvalues of t stats in testing equation')

% August 3 - changed display
disp('two in this case are for the two indicator variables given there is one threshold here')
%sept 21 write out first 4 and then others from above for ADF terms

if cols(bootcvt1)>2
horzcat(tpvalue(1,1:2),tpvaluenew)
end
if cols(bootcvt1)==2
    tpvalue
end
disp('correct?')


bootv=bootffs(round(.95*nboot1),1);
bootp1=bootffs>newtestval;bootpvalue1=cumsum(bootp1)/rows(bootffs);
bootpvalue=bootpvalue1(rows(bootpvalue1),1);
disp('test value and bootstrap 5% critical value')
horzcat(newtestval,bootv)
 

set(0,'defaultaxescolororder',[0,0,0],...
     'defaultaxeslinestyleorder','-|--|:|-.')
disp('bootstrap 5% F value')


 


disp('test value and bootstrap 5% critical value and pvalue')
horzcat(newtestval,bootv,bootpvalue)
figure(4)
prob=((1/nboot2):(1/nboot2):1);
plot(bootffs',prob,'-bl')
ylabel('Cumulative Probability')
xlabel('Test Statistic')
title('Figure X: Cumulative Density of Bootstrap Test Statistic')
% 202210 h=legend('Test Statistic',1);
 




%[te1 te2 te3]=plotdens(bootffs',1.06 *std(bootffs)*rows(bootffs)^(-1/5),1,1);
[tes1 tes2 tes3]=plotdens(bootffs);
plot(tes3,tes2,'-.r');
 ylabel('Probability')
xlabel('Test Statistic')
title('Figure X: Empirical Bootstrap Distribution of Test Statistic')
% 202210 h=legend('Test Statistic',1);
% 202210 set(h,'Interpreter','none')
%fboso=sort(seof1);


figure(103)
 x=bootffs;
 p.lB=0;
p.uB=inf;
p.alpha=0.95;
%%fhandle=figure; 
gkdeb(bootffs,p);
axis([ -1 10 0 1.5]);
p=gkdeb(bootffs);
axis([ -1 10 0 1.3]);




  


end







% ^^^^^^^^^^^^^ one threshold above
% %%%%%%%%% two thresholds below

    if numtau==3
disp('Two Thresholds')
disp('3034')
%pause
threshold1 = firstt
thresholdbelowfirstt = seconda
%
disp('thresholdbelowfirstt should be below threshold1')

%%%pause

bestjclag
%%pause
  
% check to ensure at least minobs in each subregion
jc=bestjclag;
firstc=jc;
diffd1=differe(1+pmax+jcmax-jc:rows(differe)-1-jc,1);
ehatvar=ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
 ehatlw=ehatw(1+pmax+jcmax-jc:rows(ehatw)-1-jc,1);
 dehatw1=ehatw(2+pmax+jcmax:rows(ehatw),1)-ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
  %%%%pause

disp('Seo F test ')
bestf2;
newtestval=bestf2;
 



     
   if margin==0
      
 n11=fix(perc*(rows(diffd1)));
n12=fix((1-perc)*(rows(diffd1)));
scrit=sort(diffd1);
ed1=(scrit(n12-minobs,1)-scrit(n11,1))/ngrid;
ed2=(scrit(n12,1)-scrit(n11+minobs,1))/ngrid;
%ed3=(scrit(n12,1)-scrit(n11+2*minobs,1))/ngrid;

    thresholdsa=(scrit(n11,1):ed1:scrit(n12-minobs,1))';
    thresholdse=(scrit(n11+minobs,1):ed2:scrit(n12,1))';
 %   thresholdsb=(scrit(n11+(2*minobs),1):ed3:scrit(n12,1))';
    
   else
  n11=fix(perc*(rows(ehatlw)));
n12=fix((1-perc)*(rows(ehatlw)));
scrit=sort(ehatlw);
 
ed1=(scrit(n12-minobs,1)-scrit(n11,1))/ngrid;
ed2=(scrit(n12,1)-scrit(n11+minobs,1))/ngrid;
%ed3=(scrit(n12,1)-scrit(n11+2*minobs,1))/ngrid;

    thresholdsa=(scrit(n11,1):ed1:scrit(n12-minobs,1))';
    thresholdse=(scrit(n11+minobs,1):ed2:scrit(n12,1))';
    %thresholdsb=(scrit(n11+(2*minobs),1):ed3:scrit(n12,1))';
                  
   end
  
%     
% 
% 
%    if margin==0
%       
%  n11=fix(perc*(rows(diffd1)));
% n12=fix((1-perc)*(rows(diffd1)));
% scrit=sort(diffd1);
% ed1=(scrit(n12-minobs,1)-scrit(n11,1))/ngrid;
% ed2=(scrit(n12,1)-scrit(n11+minobs,1))/ngrid;
% %ed3=(scrit(n12,1)-scrit(n11+2*minobs,1))/ngrid;
% 
%     thresholdsa=(scrit(n11,1):ed1:scrit(n12-minobs,1))';
%     thresholdse=(scrit(n11+minobs,1):ed2:scrit(n12,1))';
%  %   thresholdsb=(scrit(n11+(2*minobs),1):ed3:scrit(n12,1))';
%     
%    else
%   n11=fix(perc*(rows(ehatlw)));
% n12=fix((1-perc)*(rows(ehatlw)));
% scrit=sort(ehatlw);
%  
% ed1=(scrit(n12-minobs,1)-scrit(n11,1))/ngrid;
% ed2=(scrit(n12,1)-scrit(n11+minobs,1))/ngrid;
% %ed3=(scrit(n12,1)-scrit(n11+2*minobs,1))/ngrid;
% 
%     thresholdsa=(scrit(n11,1):ed1:scrit(n12-minobs,1))';
%     thresholdse=(scrit(n11+minobs,1):ed2:scrit(n12,1))';
%     %thresholdsb=(scrit(n11+(2*minobs),1):ed3:scrit(n12,1))';
%                   
%    end
  
thresh22e=thresholdse;
thresh22a=thresholdsa;


 

% if margin==0
%             
% for i=1:1:rows(diffd1)
%  if diffd1(i,1)<=seconda
%       indp1(i,1)=1;
%         regre1(i,1)=ehatvar(i,1);
%     else
%         regre1(i,1)=0;
%          indp1(i,1)=0;
%  end
%     if seconda<diffd1(i,1) && diffd1(i,1)<=firstt
%          indp2(i,1)=1;
%         regre2(i,1)=ehatvar(i,1);
%     else
%         regre2(i,1)=0;
%          indp2(i,1)=0;
%     end
%     if diffd1(i,1)>firstt
%          indp3(i,1)=1;
%         regre3(i,1)=ehatvar(i,1);
%     else
%         regre3(i,1)=0;
%          indp3(i,1)=0;
%     end
%  end
%  end  
%    
%  
%   
%             if margin==1
% for i=1:1:rows(ehatlw)
%      if ehatlw(i,1)<=seconda
%         regre1(i,1)=ehatvar(i,1);
%          indp1(i,1)=1;
%     else
%         regre1(i,1)=0;
%          indp1(i,1)=0;
%      end
%     if seconda<ehatlw(i,1) && ehatlw(i,1)<=firstt
%         regre2(i,1)=ehatvar(i,1);
%          indp2(i,1)=1;
%     else
%         regre2(i,1)=0;
%          indp2(i,1)=0;
%     end
%     if ehatlw(i,1)>firstt
%         regre3(i,1)=ehatvar(i,1);
%          indp3(i,1)=1;
%     else
%         regre3(i,1)=0;
%          indp3(i,1)=0;
%     end
% end
%  
%             end
  
 if margin==0
%              aregre2=((diffd1>seconda)&(diffd1<=firstt)).*ehatvar;
    % for i=1:1:rows(diffd1)
 indp1=(diffd1<=seconda);
 indp2=(diffd1>seconda)&(diffd1<=firstt);
 indp3=(diffd1>firstt);
  
           gregre1=(diffd1<=seconda).*ehatvar;
            gregre2=((diffd1>seconda)&(diffd1<=firstt)).*ehatvar;
           gregre3=(diffd1>firstt).*ehatvar;  
          
           
      
 
 end
     
  
            if margin==1
disp('3200')
%pause
          indp1=(ehatlw<=seconda);
 indp2=(ehatlw>seconda)&(ehatlw<=firstt);
 indp3=(ehatlw>firstt);
  
           gregre1=(ehatlw<=seconda).*ehatvar;
            gregre2=((ehatlw>seconda)&(ehatlw<=firstt)).*ehatvar;
           gregre3=(ehatlw>firstt).*ehatvar;  
          disp('aug13')
          horzcat(gregre1,gregre2,gregre3)
          %pause
           
       %%pause
            end
            
            numbelow1=gregre1;
            numbelow1(numbelow1==0)=[];
           smplbelow1=rows(numbelow1);
            
            numbelow2=gregre2;
            numbelow2(numbelow2==0)=[];
           smplbelow2=rows(numbelow2);
         
            numbelow3=gregre3;
            numbelow3(numbelow3==0)=[];
           smplbelow3=rows(numbelow3);
           
            disp('observations within each region')
           disp('below lowest threshold')
           smplbelow1
       
           disp('between lowest threshold and the first')
           smplbelow2
           
           disp('above the highest threshold')
           smplbelow3
            
            
           disp('total sample is ')
           rows(dehatw1)
           disp('sum of subregions is')
           smplbelow1+smplbelow2+smplbelow3 
         lkr=cumsum(indp3);
         lkr(rows(lkr))
         
            %%pause
            
%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
peterabc=horzcat(gregre1,gregre2,gregre3);
peterabc55=horzcat(gregre1,gregre2,gregre3);
 
% 
% %%%%%%late night sunday
% end
  
   
   
   %%%%%% jan14
   
    if adflag2==0
     resvarx=dehatw1-peterabc*(peterabc\dehatw1);
resvar75=resvarx;
 end

     if adflag2>0
         X1=peterabc;
         
     for i=1:adflag2
     X1 = [X1  ehatw(2+pmax+jcmax-i:rows(ehatw)-i,1)-ehatw(1+pmax+jcmax-i:rows(ehatw)-1-i,1)];
   % ehatw(2+pmax+jcmax-i:rows(ehatw)-i,1)-ehatw(1+pmax+jcmax-i:rows(ehatw)-1-i,1)
     end
      y=dehatw1;
   resvarx=y-X1*(X1\y);
     end
      
     stj2=adflag2;
     disp('two thresholds')
 fbetas=bestbetas2';
  fbetas(fbetas==0)=[];
  fts=bestt2';
  fts(fts==0)=[];
  

newtestval=bestf2;

disp('f test for coefficients on lagged residuals above and below thresholds jointly zero')
newtestval
 disp('coefficients and their t tests for null of zero')
 disp('first coeff, below the lowest threshold')
 vertcat(fbetas(1,1),fts(1,1))
 disp('second coeff, above the lowest threshold')
 vertcat(fbetas(2,1),fts(2,1))
disp('coefficients and their t tests for null of zero')
 disp('third coeff, above the highest threshold')
 vertcat(fbetas(3,1),fts(3,1))
%  
%

 
wfred=rows(fbetas);
 wfred
     disp('lag length in ADF test version')
   adflag2
 % write out ADF lagged dependent variable version if newey=2
 if wfred>3
 
     for i=4:rows(fbetas)
   
disp('ADF coefficient and t')
 vertcat(fbetas(i,1),fts(i,1))
 end
 end
  

   tau1=firstt.*ones(rows(ehatw),1); 
%   tau2=seconda.*ones(rows(ehatw),1);
%  tau3=secondb.*ones(rows(ehatw),1);
%  
if seconda<888888888888
    tau2=seconda.*ones(rows(ehatw),1);

end
  figure(90125)
   hold on
   plot(tau1,'-b')
 plot(tau2,'-r')
 %march 12 12
 if margin==0
 plot(ehatvar,'-g')
 end
 if margin==1
     plot(ehatvar,'-g')
 end
 %march 12/12
 hold off


 


%%%%%% start new ecm
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%% Estimate ECM 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 % Reset indreg12w because in line 817 is built up with lags 
 % indpss = 1 if indicator <= threshold
 % run CR regression to get residuals
%sept 12 ehatw=yd-xd*(xd\yd);
ehatw=yd-xd*(xd\yd);
 % lag those residuals and use chosen jc 
 %gee
 
 ehatlw=ehatw(1+pmax+jcmax-jc:rows(ehatw)-1-jc,1);
  
 ehatvariable=ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
 
 resids1=indp1.*ehatvariable;
 resids2=indp2.*ehatvariable;
 resids3=indp3.*ehatvariable;

% put lagged CR residuals together
rhsv=horzcat(resids1,resids2,resids3);
% resids1=indpss.*ehatlw;
% resids2=(1.0-indpss).*ehatlw;
% eddie=horzcat(indpss,1.0-indpss);
% eddie(1:20,:)
% put lagged CR residuals together
%rhsv=horzcat(resids1,resids2);
% create delta X and delta Y for ECM
newyd=yd(2+pmax+jcmax:rows(differe),1);
 dnewyd=yd(2+pmax+jcmax:rows(differe),1)-yd(1+pmax+jcmax:rows(differe)-1,1);;
 % note only picks out first column of x
 % if x contains more than 1 vbl then need to adjust code below
 %
 if cols(x)==1
 % orig below
     newxd=xd(1+pmax+jcmax:rows(differe),1);
 dnewxd=xd(2+pmax+jcmax:rows(differe),1)-xd(1+pmax+jcmax:rows(differe)-1,1);;
% original above
 else
 newxd=xd(1+pmax+jcmax:rows(differe),1:cols(x));
 dnewxd=xd(2+pmax+jcmax:rows(differe),1:cols(x))-xd(1+pmax+jcmax:rows(differe)-1,1:cols(x));;
 end
     
  yvar1=dnewyd(1+maxecmlag:rows(dnewyd),1);
 xvar1=dnewxd(1+maxecmlag:rows(dnewxd),1);
 % no lags
 
 
 if gls==0 && ecm==1
 rhsv1=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:)) ;
 else
 rhsv1=rhsv(1+maxecmlag:rows(rhsv),:);
 end
 
 results=nwestpss(yvar1,rhsv1,round(rows(yvar1)^.25));
  
 % 
 disp('ecm estimates assuming maxecmlag lagged changes in x and y, both set to be the same')
  
 
  if gls==0 && ecm==1
 xnew=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:));
  else
      xnew=rhsv(1+maxecmlag:rows(rhsv),:);
  end
 % no lags in ecm
 %results=ols(yvar1,indreg12wnew);
  
 bicnew(1)= (log((results.resid'*results.resid)/rows(results.resid)))+(log(rows(yvar1))*cols(rhsv1)/rows(yvar1));
 for j=1:rows(results.beta)
 vertcat(results.beta(j),results.tstat(j))
 end
 % lags 1 to maxecmlag
 for i=1:maxecmlag
    xnew=[xnew dnewxd(1+maxecmlag-i:rows(dnewxd)-i,:),dnewyd(1+maxecmlag-i:rows(dnewyd)-i,1)];
   results=nwestpss(yvar1,xnew,round(rows(yvar1)^.25));
   
%  % JMM added - comment lines 910 - 921 once alignment is correct
 
%  
  %%%%pause  
%    
   bicnew(i+1)= (log((results.resid'*results.resid )/rows(results.resid)))+(log(rows(yvar1))*cols(xnew)/rows(yvar1)); 
 end
 [pet1,pet2]=min(bicnew);
 sort(bicnew)'
 disp('best lag length in ecm is ')
 pet2-1
  disp('august 13 2016 override bic selection and set lag length in ecm to maxlag')
  pet2=maxecmlag+1;
  %pause
if gls==0 && ecm==1
   xnewa=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:));
else
  xnewa=rhsv(1+maxecmlag:rows(rhsv),:);
end
  for i=1:pet2-1
        xnewa=[xnewa dnewxd(1+maxecmlag-i:rows(dnewxd)-i,:),dnewyd(1+maxecmlag-i:rows(dnewyd)-i,1)];
    end
   resultsa=nwestpss(yvar1,xnewa,round(rows(yvar1)^.25));
    disp('Aug 3444 2016')
horzcat(yvar1,xnewa);
rows(xnewa);
  %pause
   
  %JMM added plot 
  figure(1)
  subplot(3,1,3)
  if gls==0 && ecm==1
  plot(rhsv1(:,2))
  else
      plot(rhsv1(:,1))
  end
  title('Lagged CR in region A')
  
  subplot(3,1,2)
  if gls==0 && ecm==1
      plot(rhsv1(:,3))
  else
      plot(rhsv1(:,2))
  end
  title('Lagged CR in region B')
  
  subplot(3,1,1)
  if gls==0 && ecm==1
      plot(rhsv1(:,4))
  else
      plot(rhsv1(:,3))
  end
  title('Lagged CR in region C')
  
  %%%%pause
   
   for j=1:rows(resultsa.beta)
       disp('ecm coefficients and t values')
       % JMM added the following line
       if gls==0 && ecm==1
        disp('dy(t) = constant, IAe(t-1), IBe(t-1), ICe(t-1), dx1(t-1), ?dx2(t-1)?, dy(t-1), ... dx1(t-pet2-1), ?dx2(t-pet2-1)?, dy(t-pet2-1)')
      else
        disp('dy(t) = IAe(t-1), IBe(t-1), ICe(t-1), d1x(t-1), ?dx(2t-1)?, dy(t-1), ... dx1(t-pet2-1), ?dx2(t-pet2-1)?, dy(t-pet2-1)')
      end
       %disp('dy(t) = constant IAe(t-1), IBe(t-1), dx(t-1), dy(t-1), ... dx(t-pet2-1), dy(t-pet2-1)')
 vertcat(resultsa.beta(j),resultsa.tstat(j))
 end  
 %%%
 disp('aug 3489 2016')
rows(yvar1);
rhsv1;
%pause
 
     
disp('Optimal Delay Parameter')
jc

disp('best lag length in ecm is ')
pet2-1

% disp('idiot Peter')
%%%%pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Estimate GARCH coefficients for ECM residuals 
%%% Take resultsa.resid and pass through the MFE toolbox GARCH procedure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if garch==1
% JMM modified lines 981 to 986
garche=resultsa.resid;

disp('Total Number of observations in ECM')
rows(garche)

disp('Mean of residuals from ECM')
mean(garche)

figure(771)
plot(garche)
title('Residuals from ECM')

garche1=garche-mean(garche);
[parameters, LL, ht, VCVrobust, VCV, scores, diagnostics] = tarch(garche1,1,0,1, 'NORMAL',2);
format long 
disp('garch parameters and robust t-stats')
garch22tstat=parameters./sqrt(diag(VCVrobust));
disp('constant')
vertcat(parameters(1,1),garch22tstat(1,1))
disp('arch')
vertcat(parameters(2,1),garch22tstat(2,1))
disp('garch')
vertcat(parameters(3,1),garch22tstat(3,1))
% August 19 - added next two lines. Remove if tarch(garche1,1,0,1, 'NORMAL',2)
%disp('gjh')
%vertcat(parameters(4,1),garch22tstat(4,1)) 
 
%%%%pause
parameters
garch22tstat
    else
    end
%%%%%%%%start x ecm    
%%%%%%%% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%% Estimate ECM 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  % Reset indreg12w because in line 817 is built up with lags 
 % indpss = 1 if indicator <= threshold
 % run CR regression to get residuals
 %sept 12 ehatw=yd-xd*(xd\yd);
ehatw=yd-xd*(xd\yd);
 % lag those residuals and use chosen jc 
 %gee
 
ehatlw=ehatw(1+pmax+jcmax-jc:rows(ehatw)-1-jc,1);


ehatvariable=ehatw(1+pmax+jcmax:rows(ehatw)-1,1);
resids1=indp1.*ehatvariable;
resids2=indp2.*ehatvariable;
resids3=indp3.*ehatvariable;

% put lagged CR residuals together
rhsv=horzcat(resids1,resids2,resids3);
  
% create delta X and delta Y for ECM
newyd=yd(1+pmax+jcmax:rows(differe),1);
 dnewyd=yd(2+pmax+jcmax:rows(differe),1)-yd(1+pmax+jcmax:rows(differe)-1,1);;
 if cols(x)==1
 newxd=xd(1+pmax+jcmax:rows(differe),1);
 dnewxd=xd(2+pmax+jcmax:rows(differe),1)-xd(1+pmax+jcmax:rows(differe)-1,1);;
 else
      newxd=xd(1+pmax+jcmax:rows(differe),1:cols(x));
 dnewxd=xd(2+pmax+jcmax:rows(differe),1:cols(x))-xd(1+pmax+jcmax:rows(differe)-1,1:cols(x));;
 end
    
 yvar1=dnewyd(1+maxecmlag:rows(dnewyd),1);
 
  % open x column ecm loop
 
 for kl=1:cols(x)
     disp('ecm for this column of x')
     kl
 xvar1=dnewxd(1+maxecmlag:rows(dnewxd),kl);
 % no lags
 
 
 if gls==0 && ecm==1
 rhsv1=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:)) ;
 else
 rhsv1=rhsv(1+maxecmlag:rows(rhsv),:);
 end
 
 results=nwestpss(xvar1,rhsv1,round(rows(xvar1)^.25));
   
 % 
 disp('ecm estimates assuming maxecmlag lagged changes in x and y, both set to be the same')
 % JMM added line 883 - delete once fixed
 disp('Be sure to check that the alignment is correct')
 
 
  if gls==0 && ecm==1
 xnew=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:));
  else
      xnew=rhsv(1+maxecmlag:rows(rhsv),:);
  end
 % no lags in ecm
 %results=ols(yvar1,indreg12wnew);
  
 bicnew(1)= (log((results.resid'*results.resid)/rows(results.resid)))+(log(rows(yvar1))*cols(rhsv1)/rows(yvar1));
 for j=1:rows(results.beta)
 vertcat(results.beta(j),results.tstat(j))
 end
 % lags 1 to maxecmlag
 for i=1:maxecmlag
   % August 3 - Changed to include all columns in X  
   xnew=[xnew dnewxd(1+maxecmlag-i:rows(dnewxd)-i,:),dnewyd(1+maxecmlag-i:rows(dnewyd)-i,1)];
   results=nwestpss(xvar1,xnew,round(rows(xvar1)^.25));
   
%   
%  
  %%%%pause  
   
   bicnew(i+1)= (log((results.resid'*results.resid )/rows(results.resid)))+(log(rows(yvar1))*cols(xnew)/rows(yvar1)); 
 end
 [pet1,pet2]=min(bicnew);
 sort(bicnew)'
 disp('best lag length in ecm is ')
 pet2-1
 disp('august 13 2016 override bic selection and set lag length in ecm to 2')
 %pause
 
 
 %%%%%%%%%%  august 13 2016 override bic selection and set lag length in
 %%%%%%%%%%  ecm equal to 2
 %%%%%%%%%%%%%%%%%%%%%%%%  
 %%%%%%%%%%%%%%%%%%%%%%%
 
 
 pet2=maxecmlag+1;
  
if gls==0 && ecm==1
   xnewa=horzcat(ones(rows(rhsv(1+maxecmlag:rows(rhsv),:)),1),rhsv(1+maxecmlag:rows(rhsv),:));
else
  xnewa=rhsv(1+maxecmlag:rows(rhsv),:);
end
  for i=1:pet2-1
      % August 3 - Changed to include all columns in X
        xnewa=[xnewa dnewxd(1+maxecmlag-i:rows(dnewxd)-i,:),dnewyd(1+maxecmlag-i:rows(dnewyd)-i,1)];
    end
   resultsa=nwestpss(xvar1,xnewa,round(rows(xvar1)^.25));
   % August 3 - Added to match MTAR
   garche=resultsa.resid;
  
   %JMM added plot 
  figure(1)
  subplot(3,1,3)
  if gls==0 && ecm==1
  plot(rhsv1(:,2))
  else
      plot(rhsv1(:,1))
  end
  title('Lagged CR in region A')
  
  subplot(3,1,2)
  if gls==0 && ecm==1
      plot(rhsv1(:,3))
  else
      plot(rhsv1(:,2))
  end
  title('Lagged CR in region B')
    
  subplot(3,1,1)
  if gls==0 && ecm==1
      plot(rhsv1(:,4))
  else
      plot(rhsv1(:,3))
  end
  title('Lagged CR in region C')
  %%%%pause
   
   for j=1:rows(resultsa.beta)
       disp('X ecm coefficients and t values')
       % JMM added the following line
       
       if gls==0 && ecm==1
        disp('dy(t) = constant, IAe(t-1), IBe(t-1), ICe(t-1), dx1(t-1), dx2(t-1), dy(t-1), ... dx1(t-pet2-1), ?dx2(t-pet2-1)?, dy(t-pet2-1)')
      else
        disp('dy(t) = IAe(t-1), IBe(t-1), ICe(t-1), dx1(t-1), dx2(t-1)dy(t-1), ... dx1(t-pet2-1), ?dx2(t-pet2-1)?, dy(t-pet2-1)')
      end  
       %disp('dx(t) = constant IAe(t-1), IBe(t-1), dx(t-1), dy(t-1), ... dx(t-pet2-1), dy(t-pet2-1)')
 vertcat(resultsa.beta(j),resultsa.tstat(j))
 end  
 %%%%pause
      
 
disp('Optimal Delay Parameter')
jc

disp('best lag length in ecm is ')
pet2-1

% disp('idiot Peter')
%%%%pause

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Estimate GARCH coefficients for ECM residuals 
%%% Take resultsa.resid and pass through the MFE toolbox GARCH procedure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% JMM modified lines 981 to 986
if garch==1
garche=resultsa.resid;

disp('Total Number of observations in ECM')
rows(garche)

disp('Mean of residuals from ECM')
mean(garche)

figure(771)
plot(garche)
title('Residuals from ECM')

garche1=garche-mean(garche);

[parameters, LL, ht, VCVrobust, VCV, scores, diagnostics] = tarch(garche1,1,0,1, 'NORMAL',2);
format long 
disp('garch parameters and robust t-stats')
garch22tstat=parameters./sqrt(diag(VCVrobust));
disp('constant')
vertcat(parameters(1,1),garch22tstat(1,1))
disp('arch')
vertcat(parameters(2,1),garch22tstat(2,1))
disp('garch')
vertcat(parameters(3,1),garch22tstat(3,1))
% August 19 - added next two lines. Remove if tarch(garche1,1,0,1, 'NORMAL',2)
%disp('gjh')
%vertcat(parameters(4,1),garch22tstat(4,1)) 
 
%%%%pause
parameters
garch22tstat
else
 end
% end loop over columns of x
 end

%%%%%%%%%%%%%%%%% end x ecm   
 


%%%%pause
format short
%%%%pause 
 
 
 



%%%%%%%%
%booter=dehatw1-peterabc*fbetas;
%size(booter)
%%%%%pause
 
booterq=resvarx;
 
 


% aug 22
% hard coded for 3 terms using estimated lag if ADF version




booteq=booterq(2:rows(booterq),1);
 
for jlss=1:nboot
     %  eboot=sample(boote,rows(dehatw),1);
     blocklen1=round(rows(booteq)/blocklen);
     %above
   eboot1=bootseo(booteq,blocklen);
% is Y1 booter(1,1)
ebootq=vertcat(booterq(1,1),eboot1);
   % eboot=sample(boote,rows(dehatw),1);
   evar=cumsum(ebootq);
   %  rdehatwboot5=evar(2:rows(evar),1)-evar(1:rows(evar)-1,1);
      
     
     ebootl=evar(1:rows(ebootq)-1,1);

     
     
     
     
 
    if rows(fbetas)>3
    for i=4:rows(fbetas)
       term(i-3,1)=fbetas(i,1)*(evar(i-1,1)-evar(i-2,1));
    end
%    end
   % aug 25 commented out end above 
dehatwboota=evar(rows(fbetas)-1:rows(evar),1)-evar(rows(fbetas)-1-1:rows(evar)-1,1);
% evar(rows(betas):rows(evar),1)-evar(rows(betas)-1:rows(evar)-1,1);
end
% aug 25 moved end above
   % eboot=sample(boote,rows(dehatw),1);
   
  
 
        
  if rows(fbetas)>3
  rdehatwboot5=vertcat(term,dehatwboota);
  end
  if rows(fbetas)==3
      rdehatwboot5=evar(2:rows(evar),1)-evar(1:rows(evar)-1,1);
  end
  
      
 
  
%%%%% 

% for jls=1:nboot
%      eboot=sample(boote,rows(dehatw),1);
%      dehatwboot=cumsum(eboot);
% ebootl=eboot(1:rows(dehatw)-1,1);
% 
derhatb1=rdehatwboot5;

 
%        
%    if margin==0
%       
%  n11=fix(perc*(rows(diffd1)));
% n12=fix((1-perc)*(rows(diffd1)));
% scrit=sort(diffd1);
% ed1=(scrit(n12-minobs,1)-scrit(n11,1))/ngrid;
% ed2=(scrit(n12,1)-scrit(n11+minobs,1))/ngrid;
% %ed3=(scrit(n12,1)-scrit(n11+2*minobs,1))/ngrid;
% 
%     thresholdsa=(scrit(n11,1):ed1:scrit(n12-minobs,1))';
%     thresholdse=(scrit(n11+minobs,1):ed2:scrit(n12,1))';
%   %  thresholdsb=(scrit(n11+(2*minobs),1):ed3:scrit(n12,1))';
%     
%    else
%   n11=fix(perc*(rows(ehatlw1)));
% n12=fix((1-perc)*(rows(ehatlw1)));
% scrit=sort(ehatlw1);
%  
% ed1=(scrit(n12-minobs,1)-scrit(n11,1))/ngrid;
% ed2=(scrit(n12,1)-scrit(n11+minobs,1))/ngrid;
% %ed3=(scrit(n12,1)-scrit(n11+2*minobs,1))/ngrid;
% 
%     thresholdsa=(scrit(n11,1):ed1:scrit(n12-minobs,1))';
%     thresholdse=(scrit(n11+minobs,1):ed2:scrit(n12,1))';
%   %  thresholdsb=(scrit(n11+(2*minobs),1):ed3:scrit(n12,1))';
%                   
%    end
  
           %if seosearch==1
%          thresholdsa=thresh22a;
%          thresholdse=thresh22e;
 threshs=horzcat(thresh22a,thresh22e);
     %end
         
[fftestboots(jlss,1),boott1s(jlss,:)]=twoboot(jc,evar,differe(1:rows(evar)),perc,margin,jcmax,adflag2,minobs,ngrid,seosearch,threshs);
%   
%   
%  counterb=0;
%   for jls=1:rows(thresholdsa);
%      
%       
%      seconda=thresholdsa(jls,1);
% for jjls=1:rows(thresholdse);
%     counterb=counterb+1;
%     firstt=thresholdse(jjls,1);
%  
%  if margin==0
%             
% for i=1:1:rows(ebootq)-1
%  if diffd(i,1)<=seconda
%         cregre1(i,1)=ebootl(i,1);
%     else
%         cregre1(i,1)=0.;
%  end
%     if seconda<diffd(i,1) && diffd(i,1)<=firstt
%         cregre2(i,1)=ebootl(i,1);
%     else
%         cregre2(i,1)=0.;
%     end
%     if diffd(i,1)>firstt
%         cregre3(i,1)=ebootl(i,1);
%     else
%         cregre3(i,1)=0.;
%     end
%  end
%  end  
%    
%  
%  
%  
%             if margin==1
% for i=1+firstc:1:rows(ebootq)-1
%      if ebootl(i-firstc,1)<=seconda
%         cregre1(i,1)=ebootl(i,1);
%     else
%         cregre1(i,1)=0.;
%      end
%     if seconda<ebootl(i-firstc,1) && ebootl(i-firstc,1)<=firstt
%         cregre2(i,1)=ebootl(i,1);
%     else
%        cregre2(i,1)=0.;
%     end
%     if ebootl(i-firstc,1)>firstt
%         cregre3(i,1)=ebootl(i,1);
%     else
%         cregre3(i,1)=0.;
%     end
% end
%  
%             end
%             
%             j1=cregre1(cregre1~=0); rj1=rows(j1);
%     j2=cregre2(cregre2~=0);rj2=rows(j2);
%     j3=cregre3(cregre3~=0);rj3=rows(j3);
%   
%    rj1;
%    rj2;
%    rj3;
%   
%   
%    if rj1>=minobs & rj2>=minobs & rj3>=minobs  
%     
% %%%%%%%%%%%%%%%%%%%%%%%%%%%
%  
%   
% peteyrabc=horzcat(cregre1,cregre2,cregre3);
%      
%       
%  
%  
% 
%   dreg12wa=peteyrabc;
%    
%         boottss99(counterb,1:adflag2+3)=zeros(1,1:adflag2+3);
% 
%      bestbetas99(counterb,1:adflag2+3)=zeros(1,1:adflag2+3);
%      
%         
%   
%    
%   
%   
%  
% %    
%    [fftestboots55(jls,1),betaboots3a,tsboot3,seosignew,revarn]=ftessadftwob(derhatb1,dreg12wa,adflag2);
%    g1=cols(tsboot3);
%    boottss99(counterb,:)=horzcat(tsboot3(1,:),zeros(1:adflag2+3-g1));
%  
% %   
%         if adflag2>0 
% %       %     newy=derhatb1(superduper1:rows(derhatb1),1);
%        [topsignew]=ftessjan(derhatb1,adflag2); 
%     else
%         topsignew=(derhatb1'*derhatb1)/rows(derhatb1);
%         end
%      fftestboots99(counterb,1)=rows(revarn)*((topsignew/seosignew)-1);
% 
%  
%   else
%        fftestboots99(counterb,1)=0;
%    boottss99(counterb,1:adflag2+3)=zeros(1,adflag2+3);
%  
%      bestbetas99(counterb,1:adflag2+3)=zeros(1,adflag2+3);
%  
%    end
%   
%   
%   end
%   
% end
%   
%   
%   
%  [h1,h2]=max(fftestboots99);
%   fftestboots(jlss,1)=fftestboots99(h2,1);
%    
%    boott1s(jlss,:)=boottss99(h2,:);
%  
% end


    end
    
boott1s = boott1s(any(boott1s,2),:) ;
fftestboots(fftestboots==0)=[];



 nboot1=rows(boott1s);
nboot2=rows(fftestboots);

boottssa=sort(boott1s);
% oldboottssa=sort(boottss) ;
boottss=boott1s;

bootcvt=boottssa(round(0.05*nboot1),:);
disp('bootstrap 5% lower tail critical values for t tests')
bootcvt
%%%%pause


%new sept 21
bootcvt1=bootcvt;
boottss1=boottssa;
% see if t tests on lagged ADF terms are symmetric
if cols(bootcvt1)>3
    disp('cols bootcvt1')
    cols(bootcvt1)
    %%%%pause
    boottss1=boottssa;
bootnew=boottss1(round(0.95*nboot1),4:cols(bootcvt1));
disp('t values on lagged ADF terms in bootstrapping test equation')
disp('lower 5% and upper 95% values, might  be similar but different sign')
cols(bootnew)
horzcat(bootcvt1(4:cols(bootcvt1)),bootnew)
 bootnew
 %%%%pause
for i=4:cols(bootcvt1)
    %compare to actual t's in testing equation
    if fts(i,1)<0
boottvalnew(:,i-3)=(boottss1(:,i))<(fts(i,1)); 
    end
    if fts(i,1)>=0
boottvalnew(:,i-3)=(boottss1(:,i))>=(fts(i,1)); 
    end
end
 
for i=4:cols(bootcvt1)
bootps1new(:,i-3)=(cumsum(boottvalnew(:,i-3)))/rows(boottss1);
tpvaluenew(1,i-3)=bootps1new(rows(bootps1new),i-3);
end
disp('pvalues of t stats on ADF coefficients in testing equation')
 
  tpvaluenew
  %%%%pause
 

end

% end new Sept 21














%%%% need boot t printout here %%%%%
% pss added aug 5  correct?
%%%%%%%%%P-Values for T-test%%%%%%%%%%%%%%%

disp('peter here')
cols(bootcvt)
for i=1:cols(bootcvt)
    %compare to actual t's in testing equation
boottval(:,i)=boottss(:,i)<fts(i,1); 
end
 
for i=1:cols(bootcvt)
bootps1(:,i)=(cumsum(boottval(:,i)))/rows(boottssa);
tpvalue(1,i)=bootps1(rows(bootps1),i);
end
disp('pvalues of t stats in testing equation')

% Change August 19 from disp('four in this case are for the three
% indicator variables given there are two thresholds here')
disp('three in this case are for the three indicator variables given there are two thresholds here')
%sept 21 write out first 4 and then others from above for ADF terms

if cols(bootcvt1)>3
horzcat(tpvalue(1,1:3),tpvaluenew)
end
if cols(bootcvt1)==3
    tpvalue
end
 
disp('correct?')

%%%%pause

%%%%%% pss added above aug 5
bootffs=sort(fftestboots);
 
figure(89030)
plot(boottssa)
ed=(1:1:rows(boottssa))';
figure(890312)
plot(ed,boottssa)
figure(8930222)
plot(boottssa,ed)

% sept 29

bootv=bootffs(round(.95*nboot2),1);
bootp1=bootffs>newtestval;bootpvalue1=cumsum(bootp1)/rows(bootffs);
bootpvalue=bootpvalue1(rows(bootpvalue1),1);
disp('test value and bootstrap 5% critical value and pvalue')
horzcat(newtestval,bootv,bootpvalue)

disp('bootstrap 5% F value')

disp('test value and bootstrap 5%')

horzcat(newtestval,bootv)

set(0,'defaultaxescolororder',[0,0,0],...
     'defaultaxeslinestyleorder','-|--|:|-.')
figure(1)
prob=((1/nboot2):(1/nboot2):1);
 

plot(bootffs',prob,'-bl')
ylabel('Cumulative Probability')
xlabel('Test Statistic')
title('Figure X: Cumulative Density of Bootstrap Test Statistic')
% 202210 h=legend('Test Statistic',1);
% 202210 set(h,'Interpreter','none')


% 
% figure (5)
% plot(bootffs)

%fboso=sort(seof1);


figure(23)
[h1 f1a y1]=pltdens(bootffs);
 plot(y1,f1a,'-.r');
 ylabel('Probability')
xlabel('Test Statistic')
title('Figure X: Empirical Bootstrap Distribution of Test Statistic')
% 202210 h=legend('Test Statistic',1);
% 202210 set(h,'Interpreter','none')

figure(100)
x=bootffs;
 p.lB=0;
p.uB=inf;
p.alpha=0.95;
%%fhandle=figure; 
gkdeb(bootffs,p);
axis([ -1 10 0 1.5]);
p=gkdeb(bootffs);
axis([ -1 10 0 1.3]);
 


    end


%%%%%%%%%%%%% two thresholds above

if numtau==1
disp('no thresholds found')
end
 
 toc
% 
% else
%     disp('Seo minobs requirement fails')
% %end
%   
% end
    
  


