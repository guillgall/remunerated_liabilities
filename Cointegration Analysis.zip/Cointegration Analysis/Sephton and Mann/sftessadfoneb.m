function [Fvalue]=sftessadfoneb(y1,x1,zmax);
% jan 25 2012
%
% specialized OLS code for two threshold cointegration test
% y is the dependent variable (delta ut in test)
% x1 is a matrix with the  various indicator series: ut-1 values below or
% equal to lower threshold, ut-1 values between the thresholds, and ut-1
% values above the upper threshold
%  d is the number of lags used in the Newey-West covariance matrix
%  
%       d  =  round(4(T/100)^.25) according to Table II of Newey-West 1994
%      
%  here d=t^.25
%  returns Wald test of restrictions that regressors are jointly zero
% 
%
%  Peter Sephton feb 2012 do not divide by t it cancels out
 
 nobs11=rows(x1);
bigt=nobs11-zmax;

 if zmax==0
    X=x1(zmax+1:nobs11,:);
    y=y1(zmax+1:nobs11,:);
  res=y-X*(X\y);
  sigseoval=res'*res;
 topsignew=(y'*y);
Fvalue=rows(y)*((topsignew/sigseoval)-1);
 end
 
 
if zmax>0    
      X=x1(zmax+1:nobs11,:);
        y=y1(zmax+1:nobs11,1);
     for i=1:1:zmax
        X = [X y1(zmax+1-i:nobs11-i,1)];
     end
 
    W=X(:,3:cols(X));
 
    resw=y-W*(W\y);
    topsignew=(resw'*resw);
 
  res9=y-X*(X\y);
  sigseoval=res9'*res9;
       
Fvalue=rows(y)*((topsignew/sigseoval)-1);
 
 
  
end
 
 