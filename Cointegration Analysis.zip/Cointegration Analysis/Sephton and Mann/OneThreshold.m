clear all;                                                                 
close all;

% Leticia 2019 07 09 (added the next 32 lines)
[notImportant, columnheader] = xlsread('Template.xlsx',1,'A1:E1');         % take the location
[data, ColumnHeaders, RawData] = xlsread('Template.xlsx',1,'A2:B202');     % take the data
SeriesA=data(:,1);
SeriesB=data(:,2);

global smplbelow1;
global smplbelow2;
global smplbelow3;
global smplbelow4;
global numtau;
global firstt;
global seconda;
global secondb;
global jc;
global cvpv;
global bootcvt1;
global c1;
global c2;
global c3;
global c4;
global tpvalue;

smplbelow1 = 0;
smplbelow2 = 0;
smplbelow3 = 0;
smplbelow4 = 0;

bootc1 = 0;
c1 = [0;0];
c2 = [0;0];
c3 = [0;0];
c4 = [0;0];

gls=0;
margin=0;
nboot=10;
blocklen=6;
jcmax=5;
pmax=10;
maxecmlag=2;
ecm=0;
garch=0;
minobs=25;
seosearch=0;
lambda=1;
ngrid=50;
perc=.15;
det=1;
ecm=0;

sm2016(SeriesA,SeriesB,det,gls,perc,margin,nboot,blocklen,jcmax,pmax,maxecmlag,ecm,garch,minobs,seosearch,lambda,ngrid)

% Leticia 2019 07 10 (taking just the odd positions on columnheader vector)
j=1;
for i=1:length(columnheader) 
    if rem(i,2) ~= 0 
        munic(j) = columnheader(i); 
        j=j+1;
    end;
end;

words = {'Locations','numtau','firstT','secondA','secondB','smplbelow1','smplbelow2','smplbelow3','smplbelow4','jc','cvpv1','cvpv2','cvpv3','bootcvt1a','bootcvt1b','bootcvt1c','gfbetsas1','gfts1','gfbetsas2','gfts2','gfbetsas3','gfts3','gfbetsas4','gfts4','tpvalue1','tpvalue2','tpvalue3'};

numbers = [numtau, firstt, seconda, secondb, smplbelow1, smplbelow2, smplbelow3, smplbelow4, jc, cvpv, bootcvt1, c1', c2', c3', c4', tpvalue];

xlswrite('test.xls', munic, 1, 'B1');
xlswrite('test.xls',words');
xlswrite('test.xls',numbers', 1, 'B2');
 
