function[yt]=glsd(ypeter,peter);
% general code to do GLS detrending for constant and trend cases
% input:    y      dependent variable to be GLS detrended
%           peter  constant(=0) or trend (=1)
% output    yt     GLS detrended series
% Peter Sephton February 2009

nobst=rows(ypeter);
if peter == 0
    cbar=-7;
    z=ones(nobst,1);
else cbar=-13.5;
    z=horzcat(ones(nobst,1),(1:1:nobst)');
end 

bar=1+(cbar/nobst);
ypeter1=zeros(nobst,1);
z1=zeros(nobst,cols(z));
ypeter1(1:1,1)=ypeter(1:1,1);
z1(1:1,:)=z(1:1,:);
 
ypeter1(2:nobst,1)=ypeter(2:nobst,1)-bar*ypeter(1:nobst-1,1);
z1(2:nobst,:)=z(2:nobst,:)-bar*z(1:nobst-1,:);

%/*constructing the gls detrended series*/
betahat=z1\ypeter1;
yt=ypeter-z*betahat;
 