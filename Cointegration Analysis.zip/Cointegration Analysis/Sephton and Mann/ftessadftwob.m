function [Fvalue,betaval,tval,sigseoval,resvar,topsignew,adflag11,sbic]=ftessadftwob(y1,x1,zmax);
% jan 25 2012
%
% specialized OLS code for two threshold cointegration test
% y is the dependent variable (delta ut in test)
% x1 is a matrix with the  various indicator series: ut-1 values below or
% equal to lower threshold, ut-1 values between the thresholds, and ut-1
% values above the upper threshold
%  d is the number of lags used in the Newey-West covariance matrix
%  
%       d  =  round(4(T/100)^.25) according to Table II of Newey-West 1994
%      
%  here d=t^.25
%  returns Wald test of restrictions that regressors are jointly zero
% 
%
%  Peter Sephton March 2011
 
 nobs11=rows(x1);
bigt=nobs11-zmax;

 if zmax==0
    X=x1(zmax+1:nobs11,:);
    y=y1(zmax+1:nobs11,:);
beta11=X\y;
[a,b]=size(X) ;
  resvar=y-X*beta11;
  res=resvar;
   ssrt=res'*res/(rows(X));
  
sigmahat(1)=ssrt;
 ssrg(1)=res'*res;
 sssig(1,1)=ssrg(1)/rows(X); 
% ignore F return
 Fvalue=0.;
 topsignew=(y'*y)/rows(y);
%beta(1:cols(X),1)=beta11;
  resultst=olsp(y,X);
  tval=resultst.tstat(1:cols(x1),1)';
betaval=resultst.beta(1:cols(x1),1)'; 
 sigseoval=sssig(1,1);
sbic=666660;
adflag11=0;
 end
 
 
if zmax>0    
      X=x1(zmax+1:nobs11,:);
        y=y1(zmax+1:nobs11,1);
 
  
     for i=1:1:zmax
        X = [X y1(zmax+1-i:nobs11-i,1)];
     end
    beta9=X\y;
    W=X(:,4:cols(X));
    betaw=W\y;
    resw=y-W*betaw;
    ssrw(1,1)=(resw'*resw)/rows(resw);
  [a,b]=size(X) ;
  res9=y-X*beta9;
   ssrt9=res9'*res9/(rows(X));
  results1=olsp(y,X);
ssssig(1,1)=ssrt9;
    tval=results1.tstat';
betaval=results1.beta';

sbic= log(ssssig(1,1))+(log(rows(X))*cols(X)/rows(X));
     
       resvar=res9;
sigseoval=ssssig(1,1) ;
    topsignew=ssrw(1,1);   
 
  adflag11=zmax;
  Fvalue=0;
  
end
 
 