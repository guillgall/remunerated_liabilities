 
[data, ColumnHeaders, RawData] = xlsread('Template.xlsx');
SeriesA=data(:,1);
SeriesB=data(:,2);

gls=0;
margin=0
nboot=10
blocklen=6
jcmax=10
pmax=10
maxecmlag=2
ecm=0;
garch=0
minobs=250
seosearch=0
lambda=1
ngrid=50
perc=.15
det=1
ecm=0

sm2016(SeriesA,SeriesB,det,gls,perc,margin,nboot,blocklen,jcmax,pmax,maxecmlag,ecm,garch,minobs,seosearch,lambda,ngrid)
 
