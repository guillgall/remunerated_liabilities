function [t] =olsps(y,X);
beta=[inv(X'*X)]*(X'*y);
res=y-X*beta;
sizeX=size(X);
sigma2=res'*res/(sizeX(1)-sizeX(2));
%  
var=inv(X'*X)*sigma2;
t=beta(1)/sqrt(var(1,1));
   
