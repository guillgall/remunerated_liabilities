function ustar=bootseoo6(eboot,b,eboot1v);
% corrected Oct 6 2021
% returns vbl already integrated
%
% x=randn(101,1);
% y=randn(101,1);
% eboot=y-x*(x\y);
% n=rows(eboot);
% n=9;
% eboot=[1 2 3 4 5 6 7 8 9]'
% b=2;
nim=rows(eboot);
k=floor((nim)/b);
 
l=k*b+1;

 t=0;
 sumterm=0;
  
      last=0;
      term=0;
     for i=1:nim-b
         last=0;
    
         for j=1:b
             last=last+eboot(i+j,1);
         end
         
           term(i,1)=(1/b)*last;
          sumterm=sumterm+term(i,1);
           
     end
     
    for t=2:nim
      
     utilde(t,1)=eboot(t,1)-(sumterm/(nim+1-b));
  
 
 end
 utildep=utilde;
  
 for i=1:nim-b
    %    blockvar(1:b,i)=utilde(1+i:b+i,1);
     blockvar(1:b,i)=utilde(1+i:b+i,1);
 end
 
  
%   peter=sample(blockvar',k,1);

 
y1(1,1)=eboot1v;
for i=2:l
    m=round((i-1)/b);
    s=round(i-m*b-1);
    
    peter=randi(nim+1-b,1);
    peter;
    if peter ==0
       while peter<=1
        peter=peter+randi(nim+1-b,1);
       end
    end
peter;
 
    if peter+s<=0
        while peter+s<1
        peter=peter+randi(nim+1-b,1);
        end
        end

peter+s;

    utildep(peter+s,1);
y1(i,1)=y1(i-1,1)+utildep(peter+s,1);
end
ustar=y1(1:l,1);
% 
%  
%  [w1,w2]=size(peter);
%  ustar=reshape(peter,k*b,1);
%  

 
%      
%      
%      
%      
%      eboot=sample(boote,rows(dehatw),1);
%      dehatwboot=cumsum(eboot);
%      ebootl=eboot(1:rows(eboot)-1,1);